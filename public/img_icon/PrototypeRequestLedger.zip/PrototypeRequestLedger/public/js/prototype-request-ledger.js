(function () {
    function cleanupPageHeader() {
        Array.prototype.forEach.call(
            document.querySelectorAll('.content-header h1 small, .content-header .description, .content-header small'),
            function (element) {
                var text = (element.textContent || '').trim();
                if (/Sheet1|Sheet2|台帳テーブル/i.test(text)) {
                    element.style.display = 'none';
                }
            }
        );
    }

    function decorateHostBox(root) {
        var hostBox = root ? root.closest('.box') : null;
        if (!hostBox) {
            return;
        }

        hostBox.classList.add('prototype-ledger-hostbox');

        var header = hostBox.querySelector('.box-header');
        if (header) {
            header.style.display = 'none';
        }

        var tools = hostBox.querySelector('.box-tools');
        if (tools) {
            tools.style.display = 'none';
        }
    }

    function refreshLedgers() {
        cleanupPageHeader();

        Array.prototype.forEach.call(document.querySelectorAll('[data-prototype-ledger-grid]'), function (root) {
            decorateHostBox(root);
            normalizeModalState(root);
            syncSelectedCount(root);
            consumeStartupAction(root);
        });

        updateBodyModalState();
    }

    function getRoot(element) {
        return element && element.closest ? element.closest('[data-prototype-ledger-grid]') : null;
    }

    function getState(root) {
        if (!root) {
            return {
                currentDetailId: null,
                detailRequestToken: 0
            };
        }

        if (!root.__prototypeLedgerState) {
            root.__prototypeLedgerState = {
                currentDetailId: null,
                detailRequestToken: 0
            };
        }

        return root.__prototypeLedgerState;
    }

    function getConfig(root) {
        return {
            tableName: root.getAttribute('data-table-name'),
            standardDataUrl: root.getAttribute('data-standard-data-url'),
            standardStoreUrl: root.getAttribute('data-standard-store-url'),
            updateUrl: root.getAttribute('data-update-url'),
            bulkUpdateUrl: root.getAttribute('data-bulk-update-url'),
            storeUrl: root.getAttribute('data-store-url'),
            detailUrl: root.getAttribute('data-detail-url'),
            documentUploadUrl: root.getAttribute('data-document-upload-url'),
            documentDeleteUrl: root.getAttribute('data-document-delete-url'),
            commentStoreUrl: root.getAttribute('data-comment-store-url'),
            commentDeleteUrl: root.getAttribute('data-comment-delete-url')
        };
    }

    function getElements(root) {
        return {
            createModal: root.querySelector('[data-ledger-modal="create"]'),
            createForm: root.querySelector('[data-create-form]'),
            createError: root.querySelector('[data-create-form-error]'),
            detailModal: root.querySelector('[data-ledger-modal="detail"]'),
            detailError: root.querySelector('[data-detail-error]'),
            detailLoading: root.querySelector('[data-detail-loading]'),
            detailBody: root.querySelector('[data-detail-body]'),
            detailTitle: root.querySelector('[data-detail-title]'),
            detailRequestNo: root.querySelector('[data-detail-request-no]'),
            detailSummaryCopy: root.querySelector('[data-detail-summary-copy]'),
            detailSummary: root.querySelector('[data-detail-summary]'),
            detailRequestFlags: root.querySelector('[data-detail-request-flags]'),
            detailPlanning: root.querySelector('[data-detail-planning]'),
            detailActual: root.querySelector('[data-detail-actual]'),
            detailNotes: root.querySelector('[data-detail-notes]'),
            detailDocumentList: root.querySelector('[data-detail-document-list]'),
            detailCommentList: root.querySelector('[data-detail-comment-list]'),
            detailIdField: root.querySelector('[data-detail-id]'),
            detailCommentIdField: root.querySelector('[data-detail-comment-id]'),
            detailDocumentForm: root.querySelector('[data-detail-document-form]'),
            detailCommentForm: root.querySelector('[data-detail-comment-form]')
        };
    }

    function getPreloadedDetails(root) {
        if (!root) {
            return {};
        }

        if (!root.__prototypeLedgerDetails) {
            var script = root.querySelector('[data-detail-store]');
            var payload = {};

            if (script) {
                try {
                    payload = JSON.parse(script.textContent || '{}') || {};
                } catch (error) {
                    payload = {};
                }
            }

            root.__prototypeLedgerDetails = payload;
        }

        return root.__prototypeLedgerDetails;
    }

    function getPreloadedDetail(root, id) {
        var details = getPreloadedDetails(root);
        return details[String(id)] || null;
    }

    function setPreloadedDetail(root, detail) {
        if (!root || !detail || !detail.id) {
            return;
        }

        getPreloadedDetails(root)[String(detail.id)] = detail;
    }

    function readResponse(response) {
        var contentType = (response.headers.get('content-type') || '').toLowerCase();

        return response.text().then(function (text) {
            var json = {};
            var isJson = contentType.indexOf('application/json') !== -1;

            if (text && isJson) {
                try {
                    json = JSON.parse(text);
                } catch (error) {
                    json = { message: text };
                }
            } else if (text) {
                json = { message: text };
            }

            if (response.redirected && /\/auth\/login(?:\?|$|\/)/.test(response.url || '')) {
                throw new Error('権限またはログイン状態を確認してください。');
            }

            if (/page expired/i.test(text)) {
                throw new Error('ページの有効期限が切れました。画面を更新してから再度お試しください。');
            }

            if (!response.ok) {
                throw new Error(json.message || '処理に失敗しました。');
            }

            if (!isJson && /^\s*</.test(text || '')) {
                throw new Error('想定外の応答が返りました。権限設定またはセッション状態を確認してください。');
            }

            return json;
        });
    }

    function csrfToken() {
        var csrf = document.querySelector('meta[name="csrf-token"]');
        return csrf ? csrf.getAttribute('content') : '';
    }

    function postForm(url, body) {
        var form = new URLSearchParams();

        Object.keys(body).forEach(function (key) {
            var value = body[key];

            if (Array.isArray(value)) {
                value.forEach(function (entry) {
                    form.append(key + '[]', entry);
                });
                return;
            }

            if (value !== undefined && value !== null) {
                form.append(key, value);
            }
        });

        return fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-CSRF-TOKEN': csrfToken()
            },
            credentials: 'same-origin',
            body: form.toString()
        }).then(readResponse);
    }

    function postMultipart(url, formData) {
        return fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': csrfToken()
            },
            credentials: 'same-origin',
            body: formData
        }).then(readResponse);
    }

    function requestMultipart(url, formData) {
        return fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': csrfToken()
            },
            credentials: 'same-origin',
            body: formData
        }).then(function (response) {
            return response.text().then(function (text) {
                return {
                    response: response,
                    text: text,
                    contentType: (response.headers.get('content-type') || '').toLowerCase()
                };
            });
        });
    }

    function getJson(url, params) {
        var query = new URLSearchParams(params || {});

        return fetch(url + '?' + query.toString(), {
            credentials: 'same-origin'
        }).then(readResponse);
    }

    function readSelectedIds(root) {
        return Array.prototype.slice.call(root.querySelectorAll('[data-row-check]:checked')).map(function (input) {
            return input.value;
        });
    }

    function syncSelectedCount(root) {
        var rowChecks = root.querySelectorAll('[data-row-check]');
        var checkedIds = readSelectedIds(root);
        var countTarget = root.querySelector('[data-selected-count]');
        var selectAll = root.querySelector('[data-select-all]');

        if (countTarget) {
            countTarget.textContent = checkedIds.length + ' 件選択';
        }

        if (selectAll) {
            selectAll.checked = rowChecks.length > 0 && checkedIds.length === rowChecks.length;
            selectAll.indeterminate = checkedIds.length > 0 && checkedIds.length < rowChecks.length;
        }
    }

    function markState(element, state) {
        ['is-saving', 'is-saved', 'is-error'].forEach(function (className) {
            element.classList.remove(className);
        });

        if (state) {
            element.classList.add(state);
        }
    }

    function showError(element, message) {
        if (!element) {
            if (message) {
                window.alert(message);
            }
            return;
        }

        element.hidden = !message;
        element.textContent = message || '';
    }

    function setButtonLoading(button, loading, loadingLabel) {
        if (!button) {
            return;
        }

        if (!button.hasAttribute('data-label')) {
            button.setAttribute('data-label', button.textContent);
        }

        button.disabled = loading;
        button.textContent = loading ? loadingLabel : button.getAttribute('data-label');
    }

    function updateBodyModalState() {
        document.body.classList.toggle(
            'prototype-ledger-modal-open',
            !!document.querySelector('.prototype-ledger-modal.is-open:not([hidden])')
        );
    }

    function normalizeModalState(root) {
        Array.prototype.forEach.call(root.querySelectorAll('.prototype-ledger-modal'), function (modal) {
            modal.classList.toggle('is-open', !modal.hidden);
        });
    }

    function consumeStartupAction(root) {
        var state = getState(root);
        var params = new URLSearchParams(window.location.search || '');
        var detailId = params.get('detail_id');
        var openCreate = params.get('open_create');

        if (state.startupHandledFor === window.location.search) {
            return;
        }

        state.startupHandledFor = window.location.search;

        if (detailId) {
            resetDetailModal(root);
            openModal(getElements(root).detailModal);
            loadDetail(root, detailId);
            params.delete('detail_id');
        } else if (openCreate === '1') {
            resetCreateModal(root);
            openModal(getElements(root).createModal);
            params.delete('open_create');
        } else {
            return;
        }

        if (window.history && window.history.replaceState) {
            var query = params.toString();
            var nextUrl = window.location.pathname + (query ? '?' + query : '') + window.location.hash;
            window.history.replaceState(window.history.state, document.title, nextUrl);
            state.startupHandledFor = query ? '?' + query : '';
        }
    }

    function openModal(modal) {
        if (!modal) {
            return;
        }

        modal.hidden = false;
        modal.classList.add('is-open');
        updateBodyModalState();
    }

    function closeModal(modal) {
        if (!modal) {
            return;
        }

        modal.hidden = true;
        modal.classList.remove('is-open');
        updateBodyModalState();
    }

    function triggerFileDownload(url) {
        if (!url) {
            return;
        }

        var frame = document.getElementById('prototype-ledger-download-frame');
        if (!frame) {
            frame = document.createElement('iframe');
            frame.id = 'prototype-ledger-download-frame';
            frame.hidden = true;
            frame.setAttribute('aria-hidden', 'true');
            document.body.appendChild(frame);
        }

        try {
            var downloadUrl = new URL(url, window.location.href);
            downloadUrl.searchParams.set('_download_at', String(Date.now()));
            frame.src = downloadUrl.toString();
        } catch (error) {
            frame.src = url;
        }
    }

    function formatCurrentDateTimeLocal() {
        var now = new Date();
        var offset = now.getTimezoneOffset();
        var local = new Date(now.getTime() - offset * 60000);
        return local.toISOString().slice(0, 16);
    }

    function normalizeStandardDateTime(value) {
        if (!value) {
            return '';
        }

        if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value)) {
            return value.replace('T', ' ') + ':00';
        }

        if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/.test(value)) {
            return value.replace('T', ' ');
        }

        return value;
    }

    function formatTodayDate() {
        var now = new Date();
        var offset = now.getTimezoneOffset();
        var local = new Date(now.getTime() - offset * 60000);
        return local.toISOString().slice(0, 10);
    }

    function normalizeStandardFieldValue(editor, value) {
        if (editor === 'datetime') {
            return normalizeStandardDateTime(value);
        }

        return value == null ? '' : value;
    }

    function parseCreatedId(url) {
        var match = String(url || '').match(/\/data\/[^/]+\/(\d+)(?:\/edit)?(?:[?#]|$)/);
        return match ? match[1] : '';
    }

    function buildStandardCreatePayload(form) {
        var payload = new FormData();
        var hiddenToken = form.querySelector('input[name="_token"]');

        payload.append('_token', hiddenToken ? hiddenToken.value : csrfToken());
        payload.append('laravel_admin_escape', '');
        payload.append('after-save', '3');
        payload.append('_previous_', window.location.href);

        Array.prototype.forEach.call(form.querySelectorAll('[name]'), function (field) {
            var fieldName = field.getAttribute('name');
            var valueKey;

            if (!fieldName || fieldName === '_token' || fieldName === 'table_name') {
                return;
            }

            if (field.type === 'file') {
                return;
            }

            valueKey = 'value[' + fieldName + ']';

            if (field.type === 'checkbox') {
                payload.set(valueKey, field.checked ? '1' : '0');
                return;
            }

            if (field.type === 'datetime-local') {
                payload.set(valueKey, normalizeStandardDateTime(field.value));
                return;
            }

            payload.set(valueKey, field.value == null ? '' : field.value);
        });

        return payload;
    }

    function buildStandardUpdatePayload(values, method) {
        var payload = new FormData();

        payload.append('_token', csrfToken());
        payload.append('laravel_admin_escape', '');
        payload.append('_previous_', window.location.href);
        payload.append('_method', method || 'PUT');
        payload.append('after-save', '4');

        Object.keys(values || {}).forEach(function (fieldName) {
            payload.append('value[' + fieldName + ']', values[fieldName] == null ? '' : values[fieldName]);
        });

        return payload;
    }

    function getCreateSupplementFiles(form) {
        var input = form.querySelector('input[type="file"][name="supplement_documents[]"]');
        return input && input.files ? Array.prototype.slice.call(input.files) : [];
    }

    function createStandardRecord(config, form) {
        return requestMultipart(config.standardStoreUrl, buildStandardCreatePayload(form)).then(function (result) {
            var response = result.response;
            var text = result.text;
            var contentType = result.contentType;
            var json = null;

            if (response.redirected && /\/auth\/login(?:\?|$|\/)/.test(response.url || '')) {
                throw new Error('権限またはログイン状態を確認してください。');
            }

            if (!response.ok) {
                throw new Error('登録に失敗しました。権限設定または入力内容を確認してください。');
            }

            if (contentType.indexOf('application/json') !== -1) {
                try {
                    json = JSON.parse(text);
                } catch (error) {
                    json = null;
                }

                if (json && json.result === false) {
                    throw new Error(json.message || '登録に失敗しました。');
                }

                return {
                    id: json && json.id ? String(json.id) : ''
                };
            }

            if (/\/create(?:[?#]|$)/.test(response.url || '') || /has-error|alert-danger|validation-error/i.test(text)) {
                throw new Error('登録に失敗しました。必須項目または権限設定を確認してください。');
            }

            return {
                id: parseCreatedId(response.url || '')
            };
        });
    }

    function uploadCreateSupplementFiles(config, id, files) {
        var formData = new FormData();

        formData.append('table_name', config.tableName);
        formData.append('id', id);

        files.forEach(function (file) {
            formData.append('supplement_files[]', file);
        });

        return postMultipart(config.documentUploadUrl, formData);
    }

    function ensureStandardResponse(result, fallbackMessage) {
        var response = result.response;
        var text = result.text;
        var contentType = result.contentType;
        var json = null;

        if (response.redirected && /\/auth\/login(?:\?|$|\/)/.test(response.url || '')) {
            throw new Error('権限またはログイン状態を確認してください。');
        }

        if (!response.ok) {
            throw new Error(fallbackMessage || '処理に失敗しました。');
        }

        if (contentType.indexOf('application/json') !== -1) {
            try {
                json = JSON.parse(text);
            } catch (error) {
                json = null;
            }

            if (json && json.result === false) {
                throw new Error(json.message || fallbackMessage || '処理に失敗しました。');
            }

            return json || {};
        }

        if (/\/(?:create|edit)(?:[?#]|$)/.test(response.url || '') && /has-error|alert-danger|validation-error/i.test(text)) {
            throw new Error(fallbackMessage || '処理に失敗しました。');
        }

        return {};
    }

    function updateStandardRecord(config, id, values) {
        return requestMultipart(
            config.standardDataUrl.replace(/\/$/, '') + '/' + id,
            buildStandardUpdatePayload(values, 'PUT')
        ).then(function (result) {
            ensureStandardResponse(result, '更新に失敗しました。権限設定または入力内容を確認してください。');
            return result;
        });
    }

    function deleteStandardRecord(config, id) {
        return requestMultipart(
            config.standardDataUrl.replace(/\/$/, '') + '/' + id,
            buildStandardUpdatePayload({}, 'DELETE')
        ).then(function (result) {
            ensureStandardResponse(result, '削除に失敗しました。権限設定を確認してください。');
            return result;
        });
    }

    function runSequential(items, worker) {
        return items.reduce(function (promise, item) {
            return promise.then(function () {
                return worker(item);
            });
        }, Promise.resolve());
    }

    function escapeHtml(text) {
        return String(text == null ? '' : text).replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;'
            }[char];
        });
    }

    function clearNode(node) {
        if (node) {
            node.innerHTML = '';
        }
    }

    function renderKeyValueList(items) {
        if (!items || !items.length) {
            return '<div class="prototype-ledger-detail-empty">データがありません。</div>';
        }

        return items.map(function (item) {
            return [
                '<div class="prototype-ledger-detail-list__row">',
                '<dt>' + escapeHtml(item.label) + '</dt>',
                '<dd>' + escapeHtml(item.value || '-') + '</dd>',
                '</div>'
            ].join('');
        }).join('');
    }

    function renderNotes(items) {
        if (!items || !items.length) {
            return '<div class="prototype-ledger-detail-empty">メモはありません。</div>';
        }

        return items.map(function (item) {
            return [
                '<article class="prototype-ledger-note">',
                '<h5>' + escapeHtml(item.label) + '</h5>',
                '<p>' + escapeHtml(item.value || '-') + '</p>',
                '</article>'
            ].join('');
        }).join('');
    }

    function renderDocuments(target, items) {
        if (!target) {
            return;
        }

        if (!items || !items.length) {
            target.innerHTML = '<div class="prototype-ledger-documents-panel__empty">まだ資料は添付されていません。</div>';
            return;
        }

        target.innerHTML = items.map(function (item) {
            return [
                '<div class="prototype-ledger-documents-panel__item">',
                '<a class="prototype-ledger-doclink" href="' + escapeHtml(item.url) + '" target="_blank" rel="noopener">' + escapeHtml(item.name) + '</a>',
                '<button type="button" class="btn btn-xs btn-danger" data-detail-document-delete="' + escapeHtml(item.uuid) + '">削除</button>',
                '</div>'
            ].join('');
        }).join('');
    }

    function renderComments(target, items) {
        if (!target) {
            return;
        }

        if (!items || !items.length) {
            target.innerHTML = '<div class="prototype-ledger-detail-empty">コメントはまだありません。</div>';
            return;
        }

        target.innerHTML = items.map(function (item) {
            var deleteButton = item.can_delete
                ? '<button type="button" class="btn btn-xs btn-default" data-detail-comment-delete="' + escapeHtml(item.suuid) + '">削除</button>'
                : '';

            return [
                '<article class="prototype-ledger-comment">',
                '<div class="prototype-ledger-comment__meta">',
                '<strong>' + escapeHtml(item.created_user || '-') + '</strong>',
                '<span>' + escapeHtml(item.created_at || '') + '</span>',
                deleteButton,
                '</div>',
                '<div class="prototype-ledger-comment__body">' + escapeHtml(item.detail || '-') + '</div>',
                '</article>'
            ].join('');
        }).join('');
    }

    function resetCreateModal(root) {
        var elements = getElements(root);

        showError(elements.createError, '');

        if (!elements.createForm) {
            return;
        }

        elements.createForm.reset();

        var requestDate = elements.createForm.querySelector('input[name="request_date"]');
        if (requestDate) {
            requestDate.value = formatCurrentDateTimeLocal();
        }
    }

    function resetDetailModal(root) {
        var elements = getElements(root);
        var state = getState(root);

        state.detailRequestToken += 1;
        state.currentDetailId = null;

        showError(elements.detailError, '');

        if (elements.detailLoading) {
            elements.detailLoading.hidden = false;
        }
        if (elements.detailBody) {
            elements.detailBody.hidden = true;
        }
        if (elements.detailTitle) {
            elements.detailTitle.textContent = '依頼詳細';
        }
        if (elements.detailRequestNo) {
            elements.detailRequestNo.textContent = '';
        }
        if (elements.detailSummaryCopy) {
            elements.detailSummaryCopy.textContent = '';
        }

        clearNode(elements.detailSummary);
        clearNode(elements.detailRequestFlags);
        clearNode(elements.detailPlanning);
        clearNode(elements.detailActual);
        clearNode(elements.detailNotes);
        clearNode(elements.detailDocumentList);
        clearNode(elements.detailCommentList);

        if (elements.detailIdField) {
            elements.detailIdField.value = '';
        }
        if (elements.detailCommentIdField) {
            elements.detailCommentIdField.value = '';
        }
        if (elements.detailDocumentForm) {
            elements.detailDocumentForm.reset();
        }
        if (elements.detailCommentForm) {
            elements.detailCommentForm.reset();
        }
    }

    function closeAllModals(root) {
        var elements = getElements(root);

        closeModal(elements.createModal);
        closeModal(elements.detailModal);
        resetCreateModal(root);
        resetDetailModal(root);
    }

    function renderDetail(root, detail) {
        var elements = getElements(root);
        var state = getState(root);

        state.currentDetailId = detail.id || null;

        if (elements.detailTitle) {
            elements.detailTitle.textContent = detail.request_no || '依頼詳細';
        }
        if (elements.detailRequestNo) {
            elements.detailRequestNo.textContent = detail.request_no || '';
        }
        if (elements.detailSummaryCopy) {
            var customer = (detail.summary || []).find(function (item) {
                return item.label === '客先';
            });
            var usage = (detail.summary || []).find(function (item) {
                return item.label === '用途';
            });

            elements.detailSummaryCopy.textContent = [customer ? customer.value : '', usage ? usage.value : '']
                .filter(Boolean)
                .join(' / ');
        }
        if (elements.detailSummary) {
            elements.detailSummary.innerHTML = renderKeyValueList(detail.summary || []);
        }
        if (elements.detailRequestFlags) {
            elements.detailRequestFlags.innerHTML = renderKeyValueList(detail.request_flags || []);
        }
        if (elements.detailPlanning) {
            elements.detailPlanning.innerHTML = renderKeyValueList(detail.planning_steps || []);
        }
        if (elements.detailActual) {
            elements.detailActual.innerHTML = renderKeyValueList(detail.actual_steps || []);
        }
        if (elements.detailNotes) {
            elements.detailNotes.innerHTML = renderNotes(detail.notes || []);
        }

        renderDocuments(elements.detailDocumentList, detail.documents || []);
        renderComments(elements.detailCommentList, detail.comments || []);

        if (elements.detailIdField) {
            elements.detailIdField.value = detail.id || '';
        }
        if (elements.detailCommentIdField) {
            elements.detailCommentIdField.value = detail.id || '';
        }
    }

    function loadDetail(root, id, options) {
        var elements = getElements(root);
        var config = getConfig(root);
        var state = getState(root);
        var requestToken = ++state.detailRequestToken;
        var settings = options || {};
        var preloaded = !settings.forceRemote ? getPreloadedDetail(root, id) : null;

        state.currentDetailId = id;

        showError(elements.detailError, '');

        if (elements.detailLoading) {
            elements.detailLoading.hidden = false;
        }
        if (elements.detailBody) {
            elements.detailBody.hidden = true;
        }

        if (preloaded) {
            renderDetail(root, preloaded);

            if (elements.detailLoading) {
                elements.detailLoading.hidden = true;
            }
            if (elements.detailBody) {
                elements.detailBody.hidden = false;
            }

            return Promise.resolve({
                result: true,
                detail: preloaded
            });
        }

        return getJson(config.detailUrl, {
            table_name: config.tableName,
            id: id
        }).then(function (json) {
            if (!document.body.contains(root) || requestToken !== getState(root).detailRequestToken) {
                return json;
            }

            setPreloadedDetail(root, json.detail || {});
            renderDetail(root, json.detail || {});

            if (elements.detailLoading) {
                elements.detailLoading.hidden = true;
            }
            if (elements.detailBody) {
                elements.detailBody.hidden = false;
            }

            return json;
        }).catch(function (error) {
            if (!document.body.contains(root) || requestToken !== getState(root).detailRequestToken) {
                return;
            }

            showError(elements.detailError, error.message);

            if (elements.detailLoading) {
                elements.detailLoading.hidden = true;
            }
        });
    }

    function handleCellSave(root, element) {
        var config = getConfig(root);
        var row = element.closest('tr');

        if (!row) {
            return;
        }

        var value = element.getAttribute('data-editor') === 'checkbox'
            ? (element.checked ? '1' : '0')
            : element.value;

        markState(element, 'is-saving');

        updateStandardRecord(config, row.getAttribute('data-row-id'), (function () {
            var payload = {};
            payload[element.getAttribute('data-column')] = normalizeStandardFieldValue(
                element.getAttribute('data-editor'),
                value
            );
            return payload;
        }())).then(function () {
            markState(element, 'is-saved');

            window.setTimeout(function () {
                markState(element, null);
            }, 900);
        }).catch(function (error) {
            markState(element, 'is-error');
            window.alert(error.message);
        });
    }

    function handleBulkAction(root, action, ids) {
        var config = getConfig(root);
        var today = formatTodayDate();

        if (!ids.length) {
            window.alert('対象行を選択してください。');
            return;
        }

        if (action === 'delete' && !window.confirm('選択した依頼を削除します。よろしいですか？')) {
            return;
        }

        var reason = null;
        if (action === 'set_cancelled') {
            reason = window.prompt('キャンセル理由を入力してください。', '');
            if (reason === null) {
                return;
            }
        }

        runSequential(ids, function (id) {
            switch (action) {
                case 'set_bulk_linked':
                    return updateStandardRecord(config, id, {
                        bulk_linked: '1',
                        bulk_linked_at: today
                    });
                case 'clear_bulk_linked':
                    return updateStandardRecord(config, id, {
                        bulk_linked: '0',
                        bulk_linked_at: ''
                    });
                case 'set_cancelled':
                    return updateStandardRecord(config, id, {
                        cancelled: '1',
                        cancelled_at: today,
                        cancel_reason: reason || ''
                    });
                case 'clear_cancelled':
                    return updateStandardRecord(config, id, {
                        cancelled: '0',
                        cancelled_at: '',
                        cancel_reason: ''
                    });
                case 'delete':
                    return deleteStandardRecord(config, id);
                default:
                    return Promise.resolve();
            }
        }).then(function () {
            window.location.reload();
        }).catch(function (error) {
            window.alert(error.message);
        });
    }

    function submitCreateForm(root, form) {
        var config = getConfig(root);
        var elements = getElements(root);
        var submitButton = form.querySelector('[data-create-submit]');
        var supplementFiles = getCreateSupplementFiles(form);

        showError(elements.createError, '');

        setButtonLoading(submitButton, true, '登録中...');

        createStandardRecord(config, form).then(function (result) {
            if (!supplementFiles.length) {
                return result;
            }

            if (!result.id) {
                throw new Error('依頼は登録されましたが、補足資料の保存先を取得できませんでした。');
            }

            return uploadCreateSupplementFiles(config, result.id, supplementFiles).then(function () {
                return result;
            });
        }).then(function () {
            window.location.reload();
        }).catch(function (error) {
            showError(elements.createError, error.message);
        }).finally(function () {
            setButtonLoading(submitButton, false);
        });
    }

    function submitDocumentForm(root, form) {
        var config = getConfig(root);
        var elements = getElements(root);
        var submitButton = form.querySelector('[data-detail-document-submit]');
        var formData = new FormData(form);
        var fileField = form.querySelector('input[type="file"]');
        var state = getState(root);

        showError(elements.detailError, '');

        if (!fileField || !fileField.files.length) {
            showError(elements.detailError, '添付するファイルを選択してください。');
            return;
        }

        setButtonLoading(submitButton, true, 'アップロード中...');

        postMultipart(config.documentUploadUrl, formData).then(function () {
            fileField.value = '';
            return loadDetail(root, state.currentDetailId, { forceRemote: true });
        }).catch(function (error) {
            showError(elements.detailError, error.message);
        }).finally(function () {
            setButtonLoading(submitButton, false);
        });
    }

    function submitCommentForm(root, form) {
        var config = getConfig(root);
        var elements = getElements(root);
        var state = getState(root);
        var submitButton = form.querySelector('[data-detail-comment-submit]');
        var textarea = form.querySelector('textarea[name="comment"]');

        showError(elements.detailError, '');

        if (!textarea || !textarea.value.trim()) {
            showError(elements.detailError, 'コメントを入力してください。');
            return;
        }

        setButtonLoading(submitButton, true, '保存中...');

        postForm(config.commentStoreUrl, {
            table_name: config.tableName,
            id: elements.detailCommentIdField ? elements.detailCommentIdField.value : '',
            comment: textarea.value
        }).then(function () {
            textarea.value = '';
            return loadDetail(root, state.currentDetailId, { forceRemote: true });
        }).catch(function (error) {
            showError(elements.detailError, error.message);
        }).finally(function () {
            setButtonLoading(submitButton, false);
        });
    }

    function deleteDetailDocument(root, documentUuid) {
        var config = getConfig(root);
        var elements = getElements(root);
        var state = getState(root);

        if (!window.confirm('この補足資料を削除します。よろしいですか？')) {
            return;
        }

        postForm(config.documentDeleteUrl, {
            table_name: config.tableName,
            id: elements.detailIdField ? elements.detailIdField.value : '',
            document_uuid: documentUuid
        }).then(function () {
            return loadDetail(root, state.currentDetailId, { forceRemote: true });
        }).catch(function (error) {
            showError(elements.detailError, error.message);
        });
    }

    function deleteDetailComment(root, commentSuuid) {
        var config = getConfig(root);
        var elements = getElements(root);
        var state = getState(root);

        if (!window.confirm('このコメントを削除します。よろしいですか？')) {
            return;
        }

        postForm(config.commentDeleteUrl, {
            table_name: config.tableName,
            id: elements.detailCommentIdField ? elements.detailCommentIdField.value : '',
            comment_suuid: commentSuuid
        }).then(function () {
            return loadDetail(root, state.currentDetailId, { forceRemote: true });
        }).catch(function (error) {
            showError(elements.detailError, error.message);
        });
    }

    function handleClick(event) {
        var trigger = event.target.closest(
            '[data-create-modal-open], [data-export-excel-url], [data-modal-close], [data-detail-open="click"], [data-bulk-action], [data-row-action], [data-detail-document-delete], [data-detail-comment-delete]'
        );

        if (!trigger) {
            return;
        }

        var root = getRoot(trigger);
        if (!root) {
            return;
        }

        if (trigger.hasAttribute('data-create-modal-open')) {
            event.preventDefault();
            resetCreateModal(root);
            openModal(getElements(root).createModal);
            return;
        }

        if (trigger.hasAttribute('data-export-excel-url')) {
            event.preventDefault();
            triggerFileDownload(trigger.getAttribute('data-export-excel-url'));
            return;
        }

        if (trigger.hasAttribute('data-modal-close')) {
            event.preventDefault();
            closeAllModals(root);
            return;
        }

        if (trigger.getAttribute('data-detail-open') === 'click') {
            event.preventDefault();
            resetDetailModal(root);
            openModal(getElements(root).detailModal);
            loadDetail(root, trigger.getAttribute('data-row-id'));
            return;
        }

        if (trigger.hasAttribute('data-bulk-action')) {
            event.preventDefault();
            handleBulkAction(root, trigger.getAttribute('data-bulk-action'), readSelectedIds(root));
            return;
        }

        if (trigger.hasAttribute('data-row-action')) {
            event.preventDefault();
            var row = trigger.closest('tr');
            if (!row) {
                return;
            }

            handleBulkAction(root, trigger.getAttribute('data-row-action'), [row.getAttribute('data-row-id')]);
            return;
        }

        if (trigger.hasAttribute('data-detail-document-delete')) {
            event.preventDefault();
            deleteDetailDocument(root, trigger.getAttribute('data-detail-document-delete'));
            return;
        }

        if (trigger.hasAttribute('data-detail-comment-delete')) {
            event.preventDefault();
            deleteDetailComment(root, trigger.getAttribute('data-detail-comment-delete'));
        }
    }

    function handleChange(event) {
        var target = event.target;
        var root = getRoot(target);

        if (!root) {
            return;
        }

        if (target.matches('[data-select-all]')) {
            Array.prototype.forEach.call(root.querySelectorAll('[data-row-check]'), function (checkbox) {
                checkbox.checked = target.checked;
            });
            syncSelectedCount(root);
            return;
        }

        if (target.matches('[data-row-check]')) {
            syncSelectedCount(root);
            return;
        }

        if (target.matches('[data-cell-editor][data-editor="select"], [data-cell-editor][data-editor="date"], [data-cell-editor][data-editor="datetime"], [data-cell-editor][data-editor="checkbox"]')) {
            handleCellSave(root, target);
        }
    }

    function handleFocusOut(event) {
        var target = event.target;
        var root = getRoot(target);

        if (!root) {
            return;
        }

        if (target.matches('[data-cell-editor][data-editor="text"], [data-cell-editor][data-editor="textarea"]')) {
            handleCellSave(root, target);
        }
    }

    function handleSubmit(event) {
        var form = event.target;
        var root = getRoot(form);

        if (!root) {
            return;
        }

        if (form.matches('[data-create-form]')) {
            event.preventDefault();
            submitCreateForm(root, form);
            return;
        }

        if (form.matches('[data-detail-document-form]')) {
            event.preventDefault();
            submitDocumentForm(root, form);
            return;
        }

        if (form.matches('[data-detail-comment-form]')) {
            event.preventDefault();
            submitCommentForm(root, form);
        }
    }

    function handleKeyDown(event) {
        if (event.key !== 'Escape') {
            return;
        }

        var modal = document.querySelector('.prototype-ledger-modal.is-open:not([hidden])');
        if (!modal) {
            return;
        }

        var root = getRoot(modal);
        if (!root) {
            return;
        }

        closeAllModals(root);
    }

    if (window.__prototypeLedgerBooted) {
        if (typeof window.PrototypeRequestLedgerRefresh === 'function') {
            window.PrototypeRequestLedgerRefresh();
        }
        return;
    }

    window.__prototypeLedgerBooted = true;
    window.PrototypeRequestLedgerRefresh = refreshLedgers;

    document.addEventListener('click', handleClick);
    document.addEventListener('change', handleChange);
    document.addEventListener('focusout', handleFocusOut);
    document.addEventListener('submit', handleSubmit);
    document.addEventListener('keydown', handleKeyDown);

    window.addEventListener('pageshow', refreshLedgers);
    window.addEventListener('popstate', function () {
        window.setTimeout(refreshLedgers, 0);
    });
    document.addEventListener('pjax:end', refreshLedgers);
    document.addEventListener('pjax:complete', refreshLedgers);
    document.addEventListener('pjax:success', refreshLedgers);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', refreshLedgers);
    } else {
        refreshLedgers();
    }
}());
