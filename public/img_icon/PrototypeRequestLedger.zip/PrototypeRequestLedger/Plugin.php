<?php

namespace App\Plugins\PrototypeRequestLedger;

use Carbon\Carbon;
use Exceedone\Exment\Enums\FileType;
use Exceedone\Exment\Enums\NotifySavedType;
use Exceedone\Exment\Enums\SystemTableName;
use Exceedone\Exment\Enums\ViewKindType;
use Exceedone\Exment\Enums\ViewType;
use Exceedone\Exment\Model\CustomColumn;
use Exceedone\Exment\Model\CustomTable;
use Exceedone\Exment\Model\CustomValue;
use Exceedone\Exment\Model\CustomView;
use Exceedone\Exment\Model\File as ExmentFile;
use Exceedone\Exment\Services\Plugin\PluginViewBase;
use Illuminate\Http\JsonResponse;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;
use Throwable;

class Plugin extends PluginViewBase
{
    protected $showHeader = false;

    protected $useBox = false;

    protected $useBoxButtons = [];

    protected $useCustomOption = true;

    protected const DEFAULT_TABLE_NAME = 'prototype_request';

    protected const DOCUMENT_INPUT_NAME = 'supplement_files';

    protected const PRESETS = [
        'full_sheet' => [
            'label' => '試作依頼一覧',
            'description' => '申請内容と進行状況を一画面で更新します。',
        ],
        'application_sheet' => [
            'label' => '開発依頼',
            'description' => 'Sheet1 相当の申請内容を中心に表示します。',
        ],
        'progress_sheet' => [
            'label' => '試作進行',
            'description' => 'Sheet2 相当の進行状況を中心に表示します。',
        ],
    ];

    protected const CREATE_FORM_SECTIONS = [
        [
            'title' => '基本情報',
            'fields' => [
                'request_date',
                'customer_name',
                'usage_purpose',
                'sales_due_date',
                'planning_finish_date',
                'planning_owner',
                'product_no',
                'progress_status',
            ],
        ],
        [
            'title' => '依頼内容',
            'fields' => [
                'analysis_required',
                'sample_greige_ship',
                'sample_finish_process',
                'design_sheet_create',
                'other_request',
                'other_detail',
                'has_greige_sample',
                'has_finish_sample',
                'has_design_sheet',
            ],
        ],
        [
            'title' => '補足情報',
            'fields' => [
                'constraint_note',
                'remarks',
                'supplement_documents',
            ],
        ],
    ];

    protected const CREATE_FIELD_CONFIG = [
        'request_date' => [
            'required' => true,
            'default_now' => true,
        ],
        'customer_name' => [
            'required' => true,
            'placeholder' => '客先名',
        ],
        'usage_purpose' => [
            'required' => true,
            'placeholder' => '用途',
        ],
        'sales_due_date' => [],
        'planning_finish_date' => [],
        'planning_owner' => [
            'placeholder' => '担当者名',
        ],
        'product_no' => [
            'placeholder' => '品番',
        ],
        'progress_status' => [
            'default' => '未着手',
        ],
        'analysis_required' => [],
        'sample_greige_ship' => [],
        'sample_finish_process' => [],
        'design_sheet_create' => [],
        'other_request' => [],
        'other_detail' => [
            'placeholder' => 'その他依頼の内容',
        ],
        'has_greige_sample' => [],
        'has_finish_sample' => [],
        'has_design_sheet' => [],
        'constraint_note' => [
            'control' => 'textarea',
            'full_width' => true,
            'placeholder' => '制約条件や注意点',
        ],
        'remarks' => [
            'control' => 'textarea',
            'full_width' => true,
            'placeholder' => '補足メモ',
        ],
        'supplement_documents' => [
            'control' => 'file',
            'label' => '補足資料',
            'full_width' => true,
            'multiple' => true,
            'hint' => 'PDF / Excel / 画像などを複数添付できます。',
        ],
    ];

    protected const PRESET_COLUMNS = [
        'application_sheet' => [
            'request_no',
            'customer_name',
            'planning_owner',
            'created_user',
            'progress_status',
            'cancelled',
            'bulk_linked',
            'request_date',
            'usage_purpose',
            'sales_due_date',
            'planning_finish_date',
            'product_no',
            'supplement_documents',
            'remarks',
            'actions',
        ],
        'progress_sheet' => [
            'request_no',
            'customer_name',
            'planning_owner',
            'progress_status',
            'created_user',
            'cancelled',
            'bulk_linked',
            'usage_purpose',
            'sales_due_date',
            'planning_finish_date',
            'product_no',
            'actual_design',
            'actual_false_twist',
            'actual_twist',
            'actual_yarn_dye',
            'actual_split',
            'actual_warping',
            'actual_drawing_in',
            'actual_weaving',
            'actual_finish_out',
            'actual_finish',
            'feedback_sent',
            'bulk_linked_at',
            'cancelled_at',
            'cancel_reason',
            'supplement_documents',
            'remarks',
            'actions',
        ],
        'full_sheet' => [
            'request_no',
            'customer_name',
            'planning_owner',
            'progress_status',
            'created_user',
            'cancelled',
            'bulk_linked',
            'request_date',
            'usage_purpose',
            'sales_due_date',
            'planning_finish_date',
            'product_no',
            'actual_design',
            'actual_false_twist',
            'actual_twist',
            'actual_yarn_dye',
            'actual_split',
            'actual_warping',
            'actual_drawing_in',
            'actual_weaving',
            'actual_finish_out',
            'actual_finish',
            'feedback_sent',
            'bulk_linked_at',
            'cancelled_at',
            'cancel_reason',
            'supplement_documents',
            'remarks',
            'actions',
        ],
    ];

    protected const COLUMN_DEFINITIONS = [
        'request_no' => ['label' => '依頼№', 'width' => 150, 'editor' => 'readonly', 'sticky' => true, 'search' => true],
        'customer_name' => ['label' => '客先', 'width' => 180, 'search' => true],
        'planning_owner' => ['label' => '企画担当', 'width' => 130],
        'created_user' => ['label' => '依頼者', 'width' => 140, 'editor' => 'readonly'],
        'progress_status' => ['label' => '進捗区分', 'width' => 120],
        'cancelled' => ['label' => 'キャンセル', 'width' => 96],
        'bulk_linked' => ['label' => 'バルク決定', 'width' => 106],
        'request_date' => ['label' => '日時', 'width' => 170],
        'usage_purpose' => ['label' => '用途', 'width' => 200, 'search' => true],
        'constraint_note' => ['label' => '備考(制約等)', 'width' => 230],
        'analysis_required' => ['label' => '分析', 'width' => 88],
        'sample_greige_ship' => ['label' => '試作生機出荷', 'width' => 120],
        'sample_finish_process' => ['label' => '試作加工仕上', 'width' => 120],
        'design_sheet_create' => ['label' => '設計表作成', 'width' => 110],
        'other_request' => ['label' => 'その他', 'width' => 88],
        'other_detail' => ['label' => 'その他詳細', 'width' => 180],
        'has_greige_sample' => ['label' => '生機サンプル有', 'width' => 120],
        'has_finish_sample' => ['label' => '仕上サンプル有', 'width' => 120],
        'has_design_sheet' => ['label' => '設計表有', 'width' => 105],
        'sales_due_date' => ['label' => '営業希望納期', 'width' => 130],
        'planning_finish_date' => ['label' => '企画仕上予定', 'width' => 130],
        'product_no' => ['label' => '品番', 'width' => 130, 'search' => true],
        'plan_analysis_design' => ['label' => '分析設計(計画)', 'width' => 126],
        'plan_material_arrival' => ['label' => '原料入荷(計画)', 'width' => 126],
        'plan_false_twist' => ['label' => '仮撚(計画)', 'width' => 116],
        'plan_twist' => ['label' => '撚糸(計画)', 'width' => 116],
        'plan_yarn_dye' => ['label' => '糸染(計画)', 'width' => 116],
        'plan_split' => ['label' => '分割(計画)', 'width' => 116],
        'plan_warping' => ['label' => '整経(計画)', 'width' => 116],
        'plan_drawing_in' => ['label' => '綾通し(計画)', 'width' => 126],
        'plan_weaving' => ['label' => '製織(計画)', 'width' => 116],
        'plan_finish_out' => ['label' => '加工出(計画)', 'width' => 126],
        'plan_finish' => ['label' => '加工仕上(計画)', 'width' => 126],
        'actual_design' => ['label' => '設計', 'width' => 108],
        'actual_false_twist' => ['label' => '仮撚', 'width' => 108],
        'actual_twist' => ['label' => '撚糸', 'width' => 108],
        'actual_yarn_dye' => ['label' => '糸染', 'width' => 108],
        'actual_split' => ['label' => '分割', 'width' => 108],
        'actual_warping' => ['label' => '整経', 'width' => 108],
        'actual_drawing_in' => ['label' => '綾通し', 'width' => 118],
        'actual_weaving' => ['label' => '製織', 'width' => 108],
        'actual_finish_out' => ['label' => '加工出', 'width' => 118],
        'actual_finish' => ['label' => '仕上', 'width' => 108],
        'feedback_sent' => ['label' => '依頼者FB', 'width' => 100],
        'bulk_linked_at' => ['label' => 'バルク決定日', 'width' => 128],
        'cancelled_at' => ['label' => 'キャンセル日', 'width' => 126],
        'cancel_reason' => ['label' => 'キャンセル理由', 'width' => 180],
        'supplement_documents' => ['label' => '補足資料', 'width' => 220, 'editor' => 'documents'],
        'remarks' => ['label' => '備考', 'width' => 220],
        'actions' => ['label' => '操作', 'width' => 150, 'editor' => 'actions'],
    ];

    public function setCustomOptionForm(&$form)
    {
        $form->text('default_table_name', '既定テーブル名')
            ->default(static::DEFAULT_TABLE_NAME)
            ->help('テンプレートで作成する試作依頼テーブル名です。通常は変更不要です。');

        $form->text('full_view_name', '一覧ビュー名')
            ->default('試作依頼_一覧');

        $form->text('application_view_name', '申請ビュー名')
            ->default('試作依頼_開発依頼');

        $form->text('progress_view_name', '進行ビュー名')
            ->default('試作依頼_試作進行');
    }

    public function setViewOptionForm($form)
    {
        $form->embeds('custom_options', '表示設定', function ($form) {
            $form->select('preset', 'プリセット')
                ->options($this->getPresetSelectOptions())
                ->default('full_sheet')
                ->required()
                ->help('Sheet1 / Sheet2 / 一覧のどれを基準に表示するかを選択します。');

            $form->number('frozen_columns', '固定列数')
                ->default(4)
                ->min(3)
                ->max(8)
                ->help('左側に固定する列数です。依頼№・客先・企画担当は固定対象になります。');

            $form->number('per_page', '1ページ件数')
                ->default(20)
                ->min(10)
                ->max(200)
                ->help('横並び一覧の初期表示件数です。');
        });

        $this->setFilterFields($form);
        $this->setSortFields($form);
    }

    public function index()
    {
        $table = $this->resolveTargetTable(request()->get('table_name'));

        return $this->pluginView('index', [
            'plugin' => $this->plugin,
            'table' => $table,
            'table_name' => $table ? $table->table_name : $this->getDefaultTableName(),
            'table_url' => $table ? admin_urls('data', $table->table_name) : null,
            'create_url' => $table ? admin_urls('data', $table->table_name, 'create') : null,
            'analysis_url' => $this->plugin->getFullUrl('analysis') . '?table_name=' . urlencode($table ? $table->table_name : $this->getDefaultTableName()),
            'setup_url' => $this->plugin->getFullUrl('setup'),
            'existing_views' => $table ? $this->getExistingPluginViews($table) : collect(),
            'preset_options' => static::PRESETS,
            'summary' => $table ? $this->buildSummary($table) : null,
        ]);
    }

    public function analysis()
    {
        $table = $this->resolveTargetTable(request()->get('table_name'));
        if (!$table) {
            abort(404, 'Target custom table was not found.');
        }

        return $this->pluginView('analysis', [
            'plugin' => $this->plugin,
            'table' => $table,
            'analysis' => $this->buildAnalysis($table),
            'table_url' => admin_urls('data', $table->table_name),
            'home_url' => $this->plugin->getFullUrl() . '?table_name=' . urlencode($table->table_name),
        ]);
    }

    public function setup()
    {
        $table = $this->resolveTargetTable(request()->get('table_name'));
        if (!$table) {
            abort(404, 'Target custom table was not found.');
        }

        foreach ($this->getSetupViewDefinitions() as $preset => $viewName) {
            $this->ensurePluginView($table, $viewName, $preset);
        }

        admin_toastr('試作依頼用のプラグインビューを作成しました。');

        return redirect($this->plugin->getFullUrl() . '?table_name=' . urlencode($table->table_name));
    }

    public function grid()
    {
        if (!$this->custom_table) {
            return $this->index();
        }

        $preset = $this->getPresetKey();
        $columns = $this->resolveColumns($preset);
        $frozenColumns = $this->getFrozenColumnsCount();
        $columns = $this->applyStickyOffsets($columns, $frozenColumns);
        $customColumns = $this->getCustomColumnsMap($this->custom_table);
        $columns = $this->hydrateColumns($columns, $customColumns);
        $paginator = $this->getGridPaginator($this->custom_table);
        $pageValues = collect($paginator->items());
        $documentMap = $this->getDocumentMap($this->custom_table, $pageValues->pluck('id')->all());
        $rows = $pageValues
            ->map(function (CustomValue $value) use ($columns, $customColumns, $documentMap) {
                return $this->serializeRow($value, $columns, $customColumns, $documentMap);
            });
        $detailsById = $this->buildPreloadedDetails($this->custom_table, $pageValues);

        return $this->pluginView('grid', [
            'plugin' => $this->plugin,
            'table' => $this->custom_table,
            'custom_view' => $this->custom_view,
            'preset_key' => $preset,
            'preset' => static::PRESETS[$preset],
            'columns' => $columns,
            'rows' => $rows,
            'paginator' => $paginator,
            'table_url' => admin_urls('data', $this->custom_table->table_name),
            'create_url' => admin_urls('data', $this->custom_table->table_name, 'create'),
            'standard_store_url' => admin_urls('data', $this->custom_table->table_name),
            'analysis_url' => $this->plugin->getFullUrl('analysis') . '?table_name=' . urlencode($this->custom_table->table_name),
            'export_url' => $this->getExportUrl($this->custom_table, $preset),
            'update_url' => $this->plugin->getFullUrl('update-cell'),
            'bulk_update_url' => $this->plugin->getFullUrl('bulk-update'),
            'store_url' => $this->plugin->getFullUrl('store'),
            'detail_url' => $this->plugin->getFullUrl('detail'),
            'document_upload_url' => $this->plugin->getFullUrl('upload-documents'),
            'document_delete_url' => $this->plugin->getFullUrl('delete-document'),
            'comment_store_url' => $this->plugin->getFullUrl('add-comment'),
            'comment_delete_url' => $this->plugin->getFullUrl('delete-comment'),
            'search' => trim((string) request()->get('q')),
            'per_page' => $paginator->perPage(),
            'create_form_sections' => $this->getCreateFormSections($this->custom_table, $customColumns),
            'details_by_id' => $detailsById,
        ]);
    }

    public function exportExcel()
    {
        $table = $this->resolveTargetTable(request()->get('table_name'));
        if (!$table) {
            abort(404, 'Target custom table was not found.');
        }

        $customView = $this->resolveRequestedCustomView($table);
        $preset = $this->resolveRequestedPreset($customView);
        $search = trim((string) request()->get('q'));
        $frozenColumns = $this->resolveRequestedFrozenColumns($customView);
        $customColumns = $this->getCustomColumnsMap($table);
        $columns = array_values(array_filter($this->resolveColumns($preset), function (array $column) {
            return $column['key'] !== 'actions';
        }));
        $columns = $this->hydrateColumns($columns, $customColumns);

        $values = $this->buildGridQuery($table, $customView, $search)->get();
        $documentMap = $this->getDocumentMap($table, $values->pluck('id')->all());
        $rows = $values->map(function (CustomValue $value) use ($columns, $customColumns, $documentMap) {
            return $this->serializeRow($value, $columns, $customColumns, $documentMap);
        })->values()->all();

        $path = $this->buildExcelExportFile($table, $customView, $preset, $columns, $rows, $search, $frozenColumns);
        $filename = sprintf(
            'prototype_request_%s_%s.xlsx',
            $preset,
            Carbon::now()->format('Ymd_His')
        );

        return response()->download(
            $path,
            $filename,
            ['Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']
        )->deleteFileAfterSend(true);
    }

    public function store(): JsonResponse
    {
        try {
            $table = $this->resolveTargetTable(request()->get('table_name'));
            if (!$table) {
                return response()->json(['message' => '対象テーブルが見つかりません。'], 404);
            }

            $value = $table->getValueModel();
            $value->setValueStrictly($this->getCreatePayload($table))->save();
            $documentCount = $this->saveDocuments($value, request()->file(static::DOCUMENT_INPUT_NAME));

            return response()->json([
                'result' => true,
                'id' => $value->id,
                'detail_url' => admin_urls('data', $table->table_name, $value->id),
                'documents' => $documentCount,
            ]);
        } catch (ValidationException $e) {
            $errors = $e->errors();
            return response()->json([
                'message' => collect($errors)->flatten()->first() ?: '入力内容を確認してください。',
                'errors' => $errors,
            ], 422);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function detail(): JsonResponse
    {
        try {
            $table = $this->resolveTargetTable(request()->get('table_name'));
            $id = (int) request()->get('id');

            if (!$table || $id <= 0) {
                return response()->json(['message' => '詳細対象が不正です。'], 422);
            }

            $value = $table->getValueModel($id);
            if (!$value) {
                return response()->json(['message' => '対象データが見つかりません。'], 404);
            }

            return response()->json([
                'result' => true,
                'detail' => $this->serializeDetail($table, $value),
            ]);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function addComment(): JsonResponse
    {
        try {
            $table = $this->resolveTargetTable(request()->get('table_name'));
            $id = (int) request()->get('id');
            $comment = trim((string) request()->get('comment'));

            if (!$table || $id <= 0 || $comment === '') {
                return response()->json(['message' => 'コメント内容を入力してください。'], 422);
            }

            $value = $table->getValueModel($id);
            if (!$value) {
                return response()->json(['message' => '対象データが見つかりません。'], 404);
            }

            $commentTable = CustomTable::getEloquent(SystemTableName::COMMENT);
            if (!$commentTable) {
                return response()->json(['message' => 'コメント機能を利用できません。'], 422);
            }

            $commentModel = $commentTable->getValueModel();
            $commentModel->parent_id = $value->id;
            $commentModel->parent_type = $table->table_name;
            $commentModel->setValue([
                'comment_detail' => $comment,
            ])->save();

            foreach ($table->notifies as $notify) {
                $notify->notifyCreateUpdateUser($value, NotifySavedType::COMMENT, ['comment' => $comment]);
            }

            return response()->json([
                'result' => true,
            ]);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function deleteComment(): JsonResponse
    {
        try {
            $table = $this->resolveTargetTable(request()->get('table_name'));
            $id = (int) request()->get('id');
            $suuid = trim((string) request()->get('comment_suuid'));

            if (!$table || $id <= 0 || $suuid === '') {
                return response()->json(['message' => '削除対象のコメントが不正です。'], 422);
            }

            $commentTable = CustomTable::getEloquent(SystemTableName::COMMENT);
            $comment = $commentTable ? $commentTable->getValueQuery()
                ->where('suuid', $suuid)
                ->where('parent_id', $id)
                ->where('parent_type', $table->table_name)
                ->first() : null;

            if (!$comment) {
                return response()->json(['message' => 'コメントが見つかりません。'], 404);
            }

            if ((int) $comment->created_user_id !== (int) \Exment::getUserId()) {
                return response()->json(['message' => 'このコメントは削除できません。'], 403);
            }

            $comment->delete();

            return response()->json([
                'result' => true,
            ]);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function uploadDocuments(): JsonResponse
    {
        try {
            $table = $this->resolveTargetTable(request()->get('table_name'));
            $id = (int) request()->get('id');

            if (!$table || $id <= 0) {
                return response()->json(['message' => '補足資料の対象が不正です。'], 422);
            }

            $value = $table->getValueModel($id);
            if (!$value) {
                return response()->json(['message' => '対象データが見つかりません。'], 404);
            }

            $count = $this->saveDocuments($value, request()->file(static::DOCUMENT_INPUT_NAME));
            if ($count === 0) {
                return response()->json(['message' => '添付するファイルを選択してください。'], 422);
            }

            return response()->json([
                'result' => true,
                'count' => $count,
            ]);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function deleteDocument(): JsonResponse
    {
        try {
            $table = $this->resolveTargetTable(request()->get('table_name'));
            $id = (int) request()->get('id');
            $documentUuid = trim((string) request()->get('document_uuid'));

            if (!$table || $id <= 0 || $documentUuid === '') {
                return response()->json(['message' => '削除対象の補足資料が不正です。'], 422);
            }

            $value = $table->getValueModel($id);
            if (!$value) {
                return response()->json(['message' => '対象データが見つかりません。'], 404);
            }

            $document = $value->getDocuments(['count' => 200])
                ->first(function ($item) use ($documentUuid) {
                    return (string) $item->getValue('file_uuid') === $documentUuid;
                });

            if (!$document) {
                return response()->json(['message' => '補足資料が見つかりません。'], 404);
            }

            ExmentFile::deleteDocumentModel($documentUuid);

            return response()->json([
                'result' => true,
            ]);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function updateCell(): JsonResponse
    {
        try {
            $table = $this->resolveTargetTable(request()->get('table_name'));
            $id = (int) request()->get('id');
            $columnName = (string) request()->get('column');

            if (!$table || $id <= 0 || $columnName === '') {
                return response()->json(['message' => '更新対象が不正です。'], 422);
            }

            $column = CustomColumn::getEloquent($columnName, $table);
            if (!$column) {
                return response()->json(['message' => '編集できない列です。'], 422);
            }

            $editor = $this->resolveEditorType($column);
            if ($editor === 'readonly' || $editor === 'actions') {
                return response()->json(['message' => '編集できない列です。'], 422);
            }

            $value = $table->getValueModel($id);
            if (!$value) {
                return response()->json(['message' => '対象データが見つかりません。'], 404);
            }

            $normalized = $this->normalizeInput(request()->get('value'), $column, $editor);
            $value->setValueStrictly([$columnName => $normalized])->save();

            return response()->json([
                'result' => true,
                'value' => $value->getValue($columnName),
                'display' => $value->getValue($columnName, true),
                'updated_at' => optional($value->updated_at)->format('Y-m-d H:i:s'),
            ]);
        } catch (ValidationException $e) {
            $errors = $e->errors();
            return response()->json([
                'message' => collect($errors)->flatten()->first() ?: '入力内容を確認してください。',
                'errors' => $errors,
            ], 422);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    public function bulkUpdate(): JsonResponse
    {
        try {
            $table = $this->resolveTargetTable(request()->get('table_name'));
            $ids = collect((array) request()->get('ids'))->filter()->map(function ($id) {
                return (int) $id;
            })->unique()->values();
            $action = (string) request()->get('action');

            if (!$table || $ids->isEmpty() || $action === '') {
                return response()->json(['message' => '一括更新パラメータが不正です。'], 422);
            }

            $values = $table->getValueQuery()->whereIn('id', $ids)->get();
            $count = 0;

            foreach ($values as $value) {
                switch ($action) {
                    case 'set_bulk_linked':
                        $value->setValue([
                            'bulk_linked' => '1',
                            'bulk_linked_at' => Carbon::today()->format('Y-m-d'),
                        ])->save();
                        $count++;
                        break;
                    case 'clear_bulk_linked':
                        $value->setValue([
                            'bulk_linked' => '0',
                            'bulk_linked_at' => null,
                        ])->save();
                        $count++;
                        break;
                    case 'set_cancelled':
                        $value->setValue([
                            'cancelled' => '1',
                            'cancelled_at' => Carbon::today()->format('Y-m-d'),
                            'cancel_reason' => request()->get('reason') ?: $value->getValue('cancel_reason'),
                        ])->save();
                        $count++;
                        break;
                    case 'clear_cancelled':
                        $value->setValue([
                            'cancelled' => '0',
                            'cancelled_at' => null,
                            'cancel_reason' => null,
                        ])->save();
                        $count++;
                        break;
                    case 'delete':
                        $value->delete();
                        $count++;
                        break;
                }
            }

            return response()->json([
                'result' => true,
                'count' => $count,
            ]);
        } catch (Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 422);
        }
    }

    protected function getDefaultTableName(): string
    {
        return (string) ($this->plugin->getCustomOption('default_table_name') ?: static::DEFAULT_TABLE_NAME);
    }

    protected function resolveTargetTable(?string $tableName = null): ?CustomTable
    {
        $tableName = $tableName ?: ($this->custom_table ? $this->custom_table->table_name : $this->getDefaultTableName());
        $table = CustomTable::getEloquent($tableName);
        if (!$table) {
            return null;
        }

        $this->ensureRequiredColumns($table);

        return CustomTable::getEloquent($table->id);
    }

    protected function getSetupViewDefinitions(): array
    {
        return [
            'full_sheet' => (string) ($this->plugin->getCustomOption('full_view_name') ?: '試作依頼_一覧'),
            'application_sheet' => (string) ($this->plugin->getCustomOption('application_view_name') ?: '試作依頼_開発依頼'),
            'progress_sheet' => (string) ($this->plugin->getCustomOption('progress_view_name') ?: '試作依頼_試作進行'),
        ];
    }

    protected function ensurePluginView(CustomTable $table, string $viewName, string $preset): void
    {
        $view = $table->custom_views
            ->first(function (CustomView $view) use ($preset) {
                return (string) $view->view_kind_type === (string) ViewKindType::PLUGIN
                    && (string) $view->getOption('plugin_id') === (string) $this->plugin->id
                    && (string) $view->getCustomOption('preset', 'full_sheet') === $preset;
            });

        if (!$view) {
            $view = CustomView::firstOrNew([
                'custom_table_id' => $table->id,
                'view_view_name' => $viewName,
                'view_kind_type' => ViewKindType::PLUGIN,
            ]);
        }

        $view->view_type = ViewType::SYSTEM;
        $view->default_flg = $preset === 'full_sheet';
        $view->setOption('plugin_id', $this->plugin->id);
        $view->setCustomOption('preset', $preset);
        $view->setCustomOption('frozen_columns', $preset === 'progress_sheet' ? 3 : 4);
        $view->setCustomOption('per_page', 20);
        $view->save();

        if ($preset === 'full_sheet') {
            CustomView::query()
                ->where('custom_table_id', $table->id)
                ->where('id', '!=', $view->id)
                ->where('default_flg', true)
                ->update(['default_flg' => false]);
        }
    }

    protected function getExistingPluginViews(CustomTable $table): Collection
    {
        return $table->custom_views
            ->filter(function (CustomView $view) {
                return (string) $view->view_kind_type === (string) ViewKindType::PLUGIN
                    && (string) $view->getOption('plugin_id') === (string) $this->plugin->id;
            })
            ->map(function (CustomView $view) use ($table) {
                return [
                    'name' => $view->view_view_name,
                    'preset' => $view->getCustomOption('preset', 'full_sheet'),
                    'url' => admin_urls_query('data', $table->table_name, ['view' => $view->suuid]),
                ];
            })
            ->values();
    }

    protected function getPresetSelectOptions(): array
    {
        return collect(static::PRESETS)
            ->mapWithKeys(function (array $preset, string $key) {
                return [$key => $preset['label']];
            })
            ->toArray();
    }

    protected function getPresetKey(): string
    {
        return $this->resolveRequestedPreset($this->custom_view);
    }

    protected function getFrozenColumnsCount(): int
    {
        return $this->resolveRequestedFrozenColumns($this->custom_view);
    }

    protected function getPerPage(): int
    {
        $perPage = request()->get('per_page')
            ?: ($this->custom_view ? $this->custom_view->getCustomOption('per_page', 20) : 20);

        return max(10, min((int) $perPage, 200));
    }

    protected function resolveRequestedPreset(?CustomView $customView = null): string
    {
        $preset = request()->get('preset')
            ?: ($customView ? $customView->getCustomOption('preset', 'full_sheet') : 'full_sheet');

        return array_key_exists($preset, static::PRESETS) ? $preset : 'full_sheet';
    }

    protected function resolveRequestedFrozenColumns(?CustomView $customView = null): int
    {
        $count = request()->get('frozen_columns')
            ?: ($customView ? $customView->getCustomOption('frozen_columns', 4) : 4);

        return max(3, min((int) $count, 8));
    }

    protected function resolveRequestedCustomView(CustomTable $table): ?CustomView
    {
        $suuid = trim((string) request()->get('view'));
        if ($suuid === '') {
            return $this->custom_view;
        }

        return CustomView::query()
            ->where('custom_table_id', $table->id)
            ->where('suuid', $suuid)
            ->first();
    }

    protected function getExportUrl(CustomTable $table, string $preset): string
    {
        $params = [
            'table_name' => $table->table_name,
            'preset' => $preset,
            'frozen_columns' => $this->getFrozenColumnsCount(),
        ];

        if ($this->custom_view) {
            $params['view'] = $this->custom_view->suuid;
        }

        $search = trim((string) request()->get('q'));
        if ($search !== '') {
            $params['q'] = $search;
        }

        return $this->plugin->getFullUrl('export-excel') . '?' . http_build_query($params);
    }

    protected function buildGridQuery(CustomTable $table, ?CustomView $customView, string $search)
    {
        $query = $table->getValueQuery();

        if ($customView) {
            $customView->filterModel($query);
            $customView->sortModel($query);
        } else {
            $query->orderBy('updated_at', 'desc');
        }

        $this->applySearch($query, $table, $search);

        return $query;
    }

    protected function resolveColumns(string $preset): array
    {
        $keys = static::PRESET_COLUMNS[$preset] ?? static::PRESET_COLUMNS['full_sheet'];

        return collect($keys)->map(function (string $key) {
            $definition = static::COLUMN_DEFINITIONS[$key] ?? ['label' => $key, 'width' => 140];
            $definition['key'] = $key;
            return $definition;
        })->toArray();
    }

    protected function applyStickyOffsets(array $columns, int $frozenCount): array
    {
        $left = 0;
        foreach ($columns as $index => &$column) {
            $column['width'] = (int) ($column['width'] ?? 140);
            $column['sticky_enabled'] = $index < $frozenCount && !isMatchString($column['key'], 'actions');
            $column['left'] = $column['sticky_enabled'] ? $left : null;
            if ($column['sticky_enabled']) {
                $left += $column['width'];
            }
        }

        return $columns;
    }

    protected function getCustomColumnsMap(CustomTable $table): Collection
    {
        return $table->custom_columns_cache->keyBy('column_name');
    }

    protected function hydrateColumns(array $columns, Collection $customColumns): array
    {
        foreach ($columns as &$column) {
            if (isset($column['editor'])) {
                $column['options'] = $column['options'] ?? [];
                continue;
            }

            $customColumn = $customColumns->get($column['key']);
            $editor = $customColumn ? $this->resolveEditorType($customColumn) : 'readonly';
            $column['editor'] = $editor;
            $column['options'] = $customColumn ? $this->resolveEditorOptions($customColumn, $editor) : [];
        }

        return $columns;
    }

    protected function getGridPaginator(CustomTable $table): LengthAwarePaginator
    {
        $query = $this->buildGridQuery($table, $this->custom_view, trim((string) request()->get('q')));
        $paginator = $query->paginate($this->getPerPage());
        $paginator->appends(request()->query());

        return $paginator;
    }

    protected function applySearch($query, CustomTable $table, string $search): void
    {
        if ($search === '') {
            return;
        }

        $targets = collect(static::COLUMN_DEFINITIONS)
            ->filter(function (array $definition) {
                return !empty($definition['search']);
            })
            ->keys()
            ->map(function (string $columnName) use ($table) {
                return CustomColumn::getEloquent($columnName, $table);
            })
            ->filter();

        $query->where(function ($innerQuery) use ($targets, $search) {
            foreach ($targets as $column) {
                $innerQuery->orWhere($column->getQueryKey(), 'LIKE', '%' . $search . '%');
            }
        });
    }

    protected function getCreateFormSections(CustomTable $table, ?Collection $customColumns = null): array
    {
        $definitions = $this->getCreateFieldDefinitions($table, $customColumns);

        return collect(static::CREATE_FORM_SECTIONS)
            ->map(function (array $section) use ($definitions) {
                $section['fields'] = collect($section['fields'])
                    ->map(function (string $key) use ($definitions) {
                        return $definitions[$key] ?? null;
                    })
                    ->filter()
                    ->values()
                    ->all();

                return $section;
            })
            ->filter(function (array $section) {
                return !empty($section['fields']);
            })
            ->values()
            ->all();
    }

    protected function getCreateFieldDefinitions(CustomTable $table, ?Collection $customColumns = null): array
    {
        $customColumns = $customColumns ?: $this->getCustomColumnsMap($table);
        $definitions = [];

        foreach (static::CREATE_FIELD_CONFIG as $fieldKey => $config) {
            if ($fieldKey === 'supplement_documents') {
                $definitions[$fieldKey] = array_merge([
                    'name' => $fieldKey,
                    'label' => '補足資料',
                    'control' => 'file',
                    'required' => false,
                    'full_width' => true,
                    'placeholder' => '',
                    'hint' => null,
                    'default' => null,
                    'options' => [],
                    'multiple' => true,
                ], $config);
                continue;
            }

            $customColumn = $customColumns->get($fieldKey);
            if (!$customColumn) {
                continue;
            }

            $editor = $this->resolveEditorType($customColumn);
            $control = $config['control'] ?? $editor;
            $default = $config['default'] ?? null;

            if (!array_key_exists('default', $config) && !empty($config['default_now']) && $editor === 'datetime') {
                $default = Carbon::now()->format('Y-m-d\TH:i');
            }

            $definitions[$fieldKey] = [
                'name' => $fieldKey,
                'label' => $config['label'] ?? ($customColumn->column_view_name ?: (static::COLUMN_DEFINITIONS[$fieldKey]['label'] ?? $fieldKey)),
                'control' => $control,
                'required' => (bool) ($config['required'] ?? false),
                'full_width' => (bool) ($config['full_width'] ?? in_array($control, ['textarea', 'file'], true)),
                'placeholder' => (string) ($config['placeholder'] ?? ''),
                'hint' => $config['hint'] ?? null,
                'default' => $default,
                'options' => $editor === 'select' ? $this->resolveEditorOptions($customColumn, $editor) : [],
                'multiple' => (bool) ($config['multiple'] ?? false),
            ];
        }

        return $definitions;
    }

    protected function getCreatePayload(CustomTable $table): array
    {
        $customColumns = $this->getCustomColumnsMap($table);
        $definitions = $this->getCreateFieldDefinitions($table, $customColumns);
        $payload = [];

        foreach ($definitions as $fieldKey => $definition) {
            if ($fieldKey === 'supplement_documents') {
                continue;
            }

            $customColumn = $customColumns->get($fieldKey);
            if (!$customColumn) {
                continue;
            }

            $editor = $this->resolveEditorType($customColumn);
            $input = $editor === 'checkbox'
                ? (request()->has($fieldKey) ? request()->input($fieldKey) : '0')
                : request()->input($fieldKey);

            if (is_nullorempty($input) && array_key_exists('default', $definition) && !is_nullorempty($definition['default'])) {
                $input = $definition['default'];
            }

            $payload[$fieldKey] = $this->normalizeInput($input, $customColumn, $editor);
        }

        return $payload;
    }

    protected function saveDocuments(CustomValue $value, $files): int
    {
        $files = is_array($files) ? $files : array_filter([$files]);
        $count = 0;

        foreach ($files as $file) {
            if (!$file) {
                continue;
            }

            $document = ExmentFile::storeAs(
                FileType::CUSTOM_VALUE_DOCUMENT,
                $file,
                $value->custom_table->table_name,
                $file->getClientOriginalName()
            );
            $document->saveDocumentModel($value, $file->getClientOriginalName());
            $count++;
        }

        return $count;
    }

    protected function serializeDetail(CustomTable $table, CustomValue $value): array
    {
        $documents = $this->getSafeDocumentList($table, $value->id);
        $comments = $this->getSafeCommentList($table, $value->id);

        return [
            'id' => $value->id,
            'request_no' => $this->displayValue($value, 'request_no'),
            'detail_url' => admin_urls('data', $table->table_name, $value->id),
            'summary' => [
                ['label' => '依頼番号', 'value' => $this->displayValue($value, 'request_no')],
                ['label' => '依頼者', 'value' => $this->displayCreatedUser($value)],
                ['label' => '進捗区分', 'value' => $this->displayValue($value, 'progress_status')],
                ['label' => '日時', 'value' => $this->displayValue($value, 'request_date')],
                ['label' => '客先', 'value' => $this->displayValue($value, 'customer_name')],
                ['label' => '用途', 'value' => $this->displayValue($value, 'usage_purpose')],
                ['label' => '営業希望納期', 'value' => $this->displayValue($value, 'sales_due_date')],
                ['label' => '企画仕上予定', 'value' => $this->displayValue($value, 'planning_finish_date')],
                ['label' => '企画担当', 'value' => $this->displayValue($value, 'planning_owner')],
                ['label' => '品番', 'value' => $this->displayValue($value, 'product_no')],
                ['label' => 'バルク決定', 'value' => $this->yesNoLabel($value->getValue('bulk_linked'))],
                ['label' => 'キャンセル', 'value' => $this->yesNoLabel($value->getValue('cancelled'))],
            ],
            'request_flags' => [
                ['label' => '分析', 'value' => $this->yesNoLabel($value->getValue('analysis_required'))],
                ['label' => '試作生機出荷', 'value' => $this->yesNoLabel($value->getValue('sample_greige_ship'))],
                ['label' => '試作加工仕上', 'value' => $this->yesNoLabel($value->getValue('sample_finish_process'))],
                ['label' => '設計表作成', 'value' => $this->yesNoLabel($value->getValue('design_sheet_create'))],
                ['label' => 'その他依頼', 'value' => $this->yesNoLabel($value->getValue('other_request'))],
                ['label' => 'その他詳細', 'value' => $this->displayValue($value, 'other_detail')],
                ['label' => '生機サンプル有', 'value' => $this->yesNoLabel($value->getValue('has_greige_sample'))],
                ['label' => '仕上サンプル有', 'value' => $this->yesNoLabel($value->getValue('has_finish_sample'))],
                ['label' => '設計表有', 'value' => $this->yesNoLabel($value->getValue('has_design_sheet'))],
            ],
            'planning_steps' => [
                ['label' => '分析設計', 'value' => $this->displayValue($value, 'plan_analysis_design')],
                ['label' => '原料入荷', 'value' => $this->displayValue($value, 'plan_material_arrival')],
                ['label' => '仮撚', 'value' => $this->displayValue($value, 'plan_false_twist')],
                ['label' => '撚糸', 'value' => $this->displayValue($value, 'plan_twist')],
                ['label' => '糸染', 'value' => $this->displayValue($value, 'plan_yarn_dye')],
                ['label' => '分割', 'value' => $this->displayValue($value, 'plan_split')],
                ['label' => '整経', 'value' => $this->displayValue($value, 'plan_warping')],
                ['label' => '綾通し', 'value' => $this->displayValue($value, 'plan_drawing_in')],
                ['label' => '製織', 'value' => $this->displayValue($value, 'plan_weaving')],
                ['label' => '加工出', 'value' => $this->displayValue($value, 'plan_finish_out')],
                ['label' => '加工仕上', 'value' => $this->displayValue($value, 'plan_finish')],
            ],
            'actual_steps' => [
                ['label' => '設計', 'value' => $this->displayValue($value, 'actual_design')],
                ['label' => '仮撚', 'value' => $this->displayValue($value, 'actual_false_twist')],
                ['label' => '撚糸', 'value' => $this->displayValue($value, 'actual_twist')],
                ['label' => '糸染', 'value' => $this->displayValue($value, 'actual_yarn_dye')],
                ['label' => '分割', 'value' => $this->displayValue($value, 'actual_split')],
                ['label' => '整経', 'value' => $this->displayValue($value, 'actual_warping')],
                ['label' => '綾通し', 'value' => $this->displayValue($value, 'actual_drawing_in')],
                ['label' => '製織', 'value' => $this->displayValue($value, 'actual_weaving')],
                ['label' => '加工出', 'value' => $this->displayValue($value, 'actual_finish_out')],
                ['label' => '仕上', 'value' => $this->displayValue($value, 'actual_finish')],
                ['label' => '依頼者FB', 'value' => $this->yesNoLabel($value->getValue('feedback_sent'))],
            ],
            'notes' => [
                ['label' => '備考(制約等)', 'value' => $this->displayValue($value, 'constraint_note')],
                ['label' => 'キャンセル理由', 'value' => $this->displayValue($value, 'cancel_reason')],
                ['label' => '備考', 'value' => $this->displayValue($value, 'remarks')],
            ],
            'documents' => $documents,
            'comments' => $comments,
        ];
    }

    protected function getSafeDocumentList(CustomTable $table, int $id): array
    {
        try {
            return $this->getDocumentMap($table, [$id])->get($id, collect())->values()->all();
        } catch (Throwable $e) {
            return [];
        }
    }

    protected function getSafeCommentList(CustomTable $table, int $id): array
    {
        try {
            return $this->serializeComments($table, $id);
        } catch (Throwable $e) {
            return [];
        }
    }

    protected function getDocumentMap(CustomTable $table, array $parentIds): Collection
    {
        if (empty($parentIds)) {
            return collect();
        }

        try {
            $documentTable = CustomTable::getEloquent('document');
        } catch (Throwable $e) {
            return collect();
        }

        if (!$documentTable) {
            return collect();
        }

        try {
            return $documentTable->getValueQuery()
                ->where('parent_type', $table->table_name)
                ->whereIn('parent_id', $parentIds)
                ->get()
                ->groupBy('parent_id')
                ->map(function (Collection $documents) {
                    return $documents->map(function (CustomValue $document) {
                        $uuid = (string) ($document->getValue('file_uuid') ?: '');
                        $url = ExmentFile::getUrl($uuid);
                        if ($uuid === '' || !$url) {
                            return null;
                        }

                        return [
                            'uuid' => $uuid,
                            'name' => (string) ($document->getValue('document_name', true) ?: $document->getValue('document_name') ?: $uuid),
                            'url' => $url,
                        ];
                    })->filter()->values();
                });
        } catch (Throwable $e) {
            return collect();
        }
    }

    protected function serializeComments(CustomTable $table, int $id): array
    {
        try {
            $query = $this->getCommentQuery($table, $id);
        } catch (Throwable $e) {
            return [];
        }

        if (!$query) {
            return [];
        }

        try {
            return $query->get()
                ->map(function (CustomValue $comment) {
                    return [
                        'suuid' => $comment->suuid,
                        'detail' => $this->displayValue($comment, 'comment_detail'),
                        'created_user' => $this->displayCreatedUser($comment),
                        'created_at' => optional($comment->created_at)->format('Y-m-d H:i'),
                        'can_delete' => (int) $comment->created_user_id === (int) \Exment::getUserId(),
                    ];
                })
                ->values()
                ->all();
        } catch (Throwable $e) {
            return [];
        }
    }

    protected function buildPreloadedDetails(CustomTable $table, Collection $pageValues): array
    {
        $values = $pageValues->keyBy('id');
        $requestedDetailId = (int) request()->get('detail_id');

        if ($requestedDetailId > 0 && !$values->has($requestedDetailId)) {
            try {
                $requestedValue = $table->getValueModel($requestedDetailId);
                if ($requestedValue) {
                    $values->put($requestedDetailId, $requestedValue);
                }
            } catch (Throwable $e) {
            }
        }

        return $values->mapWithKeys(function (CustomValue $value) use ($table) {
            return [
                (string) $value->id => $this->serializeDetail($table, $value),
            ];
        })->all();
    }

    protected function ensureRequiredColumns(CustomTable $table): void
    {
        $definitions = [
            'plan_yarn_dye' => [
                'column_view_name' => '糸染(計画)',
                'column_type' => 'date',
                'order' => 29,
                'options' => [],
            ],
            'actual_yarn_dye' => [
                'column_view_name' => '糸染',
                'column_type' => 'date',
                'order' => 39,
                'options' => [],
            ],
        ];

        foreach ($definitions as $columnName => $definition) {
            $column = CustomColumn::getEloquent($columnName, $table);
            if ($column) {
                continue;
            }

            try {
                $column = CustomColumn::firstOrNew([
                    'custom_table_id' => $table->id,
                    'column_name' => $columnName,
                ]);
                $column->column_view_name = $definition['column_view_name'];
                $column->column_type = $definition['column_type'];
                $column->order = $definition['order'];
                $column->options = $definition['options'];
                $column->save();
            } catch (Throwable $e) {
                continue;
            }
        }
    }

    protected function getCommentQuery(CustomTable $table, int $id)
    {
        $commentTable = CustomTable::getEloquent(SystemTableName::COMMENT);
        if (!$commentTable) {
            return null;
        }

        return $commentTable->getValueQuery()
            ->where('parent_id', $id)
            ->where('parent_type', $table->table_name)
            ->orderBy('created_at', 'asc');
    }

    protected function serializeRow(CustomValue $value, array $columns, Collection $customColumns, Collection $documentMap): array
    {
        $tableName = $this->custom_table ? $this->custom_table->table_name : $this->getDefaultTableName();
        $documents = $documentMap->get($value->id, collect())->values()->all();
        $cells = [];

        foreach ($columns as $column) {
            $key = $column['key'];
            $customColumn = $customColumns->get($key);
            $cells[$key] = $this->resolveCellValue($value, $column, $customColumn, $documents);
        }

        return [
            'id' => $value->id,
            'detail_url' => admin_urls('data', $tableName, $value->id),
            'edit_url' => admin_urls('data', $tableName, $value->id, 'edit'),
            'cells' => $cells,
        ];
    }

    protected function buildExcelExportFile(
        CustomTable $table,
        ?CustomView $customView,
        string $preset,
        array $columns,
        array $rows,
        string $search,
        int $frozenColumns
    ): string {
        $path = tempnam(sys_get_temp_dir(), 'prototype_request_xlsx_');
        $zip = new \ZipArchive();

        if ($path === false || $zip->open($path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            throw new \RuntimeException('Excel export file could not be created.');
        }

        $sheetName = $this->resolveExcelSheetName(static::PRESETS[$preset]['label'] ?? '試作依頼');
        $title = sprintf('試作依頼台帳 - %s', static::PRESETS[$preset]['label'] ?? '試作依頼一覧');
        $exportedAt = Carbon::now();

        $zip->addFromString('[Content_Types].xml', $this->getExcelContentTypesXml());
        $zip->addFromString('_rels/.rels', $this->getExcelRootRelationshipsXml());
        $zip->addFromString('docProps/app.xml', $this->getExcelAppPropertiesXml($sheetName));
        $zip->addFromString('docProps/core.xml', $this->getExcelCorePropertiesXml($title, $exportedAt));
        $zip->addFromString('xl/workbook.xml', $this->getExcelWorkbookXml($sheetName));
        $zip->addFromString('xl/_rels/workbook.xml.rels', $this->getExcelWorkbookRelationshipsXml());
        $zip->addFromString('xl/styles.xml', $this->getExcelStylesXml());
        $zip->addFromString('xl/worksheets/sheet1.xml', $this->getExcelWorksheetXml(
            $table,
            $customView,
            $title,
            $columns,
            $rows,
            $search,
            $frozenColumns,
            $exportedAt
        ));
        $zip->close();

        return $path;
    }

    protected function getExcelWorksheetXml(
        CustomTable $table,
        ?CustomView $customView,
        string $title,
        array $columns,
        array $rows,
        string $search,
        int $frozenColumns,
        Carbon $exportedAt
    ): string {
        $columnCount = max(count($columns), 1);
        $lastColumn = $this->getExcelColumnLetter($columnCount);
        $freezeX = max(0, min($frozenColumns, $columnCount));
        $topLeftColumn = $this->getExcelColumnLetter(max(1, $freezeX + 1));
        $metaText = sprintf(
            'ビュー: %s / 件数: %d / 検索: %s / 出力日時: %s',
            $customView ? $customView->view_view_name : ($table->table_view_name ?: $table->table_name),
            count($rows),
            $search === '' ? 'なし' : $search,
            $exportedAt->format('Y-m-d H:i')
        );

        $colsXml = '';
        foreach (array_values($columns) as $index => $column) {
            $width = max(12, min(42, round(((int) ($column['width'] ?? 140)) / 7, 1)));
            $colIndex = $index + 1;
            $colsXml .= sprintf(
                '<col min="%1$d" max="%1$d" width="%2$s" customWidth="1"/>',
                $colIndex,
                number_format($width, 1, '.', '')
            );
        }

        $rowsXml = '';
        $rowsXml .= '<row r="1" ht="30" customHeight="1">';
        $rowsXml .= $this->getExcelCellXml('A1', $title, 1);
        $rowsXml .= '</row>';
        $rowsXml .= '<row r="2" ht="22" customHeight="1">';
        $rowsXml .= $this->getExcelCellXml('A2', $metaText, 2);
        $rowsXml .= '</row>';
        $rowsXml .= '<row r="3" ht="10" customHeight="1"/>';

        $rowsXml .= '<row r="4" ht="24" customHeight="1">';
        foreach (array_values($columns) as $index => $column) {
            $cellRef = $this->getExcelColumnLetter($index + 1) . '4';
            $rowsXml .= $this->getExcelCellXml($cellRef, (string) ($column['label'] ?? $column['key']), 3);
        }
        $rowsXml .= '</row>';

        foreach (array_values($rows) as $rowIndex => $row) {
            $excelRow = $rowIndex + 5;
            $hasWrappedCell = false;
            $cellsXml = '';

            foreach (array_values($columns) as $columnIndex => $column) {
                $cellRef = $this->getExcelColumnLetter($columnIndex + 1) . $excelRow;
                $value = $this->resolveExportCellText($row['cells'][$column['key']] ?? [], $column);
                $wrap = $this->shouldWrapExcelCell($value, $column);
                $styleId = $wrap
                    ? ($rowIndex % 2 === 0 ? 6 : 7)
                    : ($rowIndex % 2 === 0 ? 4 : 5);

                if ($wrap) {
                    $hasWrappedCell = true;
                }

                $cellsXml .= $this->getExcelCellXml($cellRef, $value, $styleId);
            }

            $rowHeight = $hasWrappedCell ? 34 : 22;
            $rowsXml .= sprintf('<row r="%d" ht="%d" customHeight="1">%s</row>', $excelRow, $rowHeight, $cellsXml);
        }

        $mergeCells = sprintf(
            '<mergeCells count="2"><mergeCell ref="A1:%1$s1"/><mergeCell ref="A2:%1$s2"/></mergeCells>',
            $lastColumn
        );
        $autoFilter = sprintf('<autoFilter ref="A4:%s4"/>', $lastColumn);
        $lastRowNumber = max(4, count($rows) + 4);

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheetPr><outlinePr summaryBelow="1" summaryRight="1"/><pageSetUpPr/></sheetPr>'
            . sprintf('<dimension ref="A1:%s%d"/>', $lastColumn, $lastRowNumber)
            . '<sheetViews><sheetView workbookViewId="0" tabSelected="1">'
            . sprintf(
                '<pane xSplit="%d" ySplit="4" topLeftCell="%s5" activePane="bottomRight" state="frozen"/>',
                $freezeX,
                $topLeftColumn
            )
            . '<selection pane="topRight"/><selection pane="bottomLeft"/><selection pane="bottomRight" activeCell="A1" sqref="A1"/>'
            . '</sheetView></sheetViews>'
            . '<sheetFormatPr baseColWidth="8" defaultRowHeight="20"/>'
            . '<cols>' . $colsXml . '</cols>'
            . '<sheetData>' . $rowsXml . '</sheetData>'
            . $autoFilter
            . $mergeCells
            . '<pageMargins left="0.75" right="0.75" top="1" bottom="1" header="0.5" footer="0.5"/>'
            . '</worksheet>';
    }

    protected function getExcelStylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<fonts count="3">'
            . '<font><sz val="10"/><color rgb="FF243140"/><name val="Yu Gothic UI"/><family val="2"/></font>'
            . '<font><b/><sz val="16"/><color rgb="FFFFFFFF"/><name val="Yu Gothic UI"/><family val="2"/></font>'
            . '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Yu Gothic UI"/><family val="2"/></font>'
            . '</fonts>'
            . '<fills count="5">'
            . '<fill><patternFill patternType="none"/></fill>'
            . '<fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF0F7A45"/><bgColor indexed="64"/></patternFill></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF28435C"/><bgColor indexed="64"/></patternFill></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FFF7FAFD"/><bgColor indexed="64"/></patternFill></fill>'
            . '</fills>'
            . '<borders count="2">'
            . '<border><left/><right/><top/><bottom/><diagonal/></border>'
            . '<border>'
            . '<left style="thin"><color rgb="FFD6E0EA"/></left>'
            . '<right style="thin"><color rgb="FFD6E0EA"/></right>'
            . '<top style="thin"><color rgb="FFD6E0EA"/></top>'
            . '<bottom style="thin"><color rgb="FFD6E0EA"/></bottom>'
            . '<diagonal/>'
            . '</border>'
            . '</borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="8">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
            . '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>'
            . '<xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>'
            . '<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top"/></xf>'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top" wrapText="1"/></xf>'
            . '<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="top" wrapText="1"/></xf>'
            . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }

    protected function getExcelContentTypesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            . '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '</Types>';
    }

    protected function getExcelRootRelationshipsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
            . '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
            . '</Relationships>';
    }

    protected function getExcelWorkbookXml(string $sheetName): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="24000" windowHeight="14000"/></bookViews>'
            . '<sheets>'
            . sprintf('<sheet name="%s" sheetId="1" r:id="rId1"/>', $this->escapeExcelXml($sheetName))
            . '</sheets>'
            . '</workbook>';
    }

    protected function getExcelWorkbookRelationshipsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>';
    }

    protected function getExcelAppPropertiesXml(string $sheetName): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
            . '<Application>Exment</Application>'
            . '<DocSecurity>0</DocSecurity>'
            . '<ScaleCrop>false</ScaleCrop>'
            . '<HeadingPairs><vt:vector size="2" baseType="variant"><vt:variant><vt:lpstr>Worksheets</vt:lpstr></vt:variant><vt:variant><vt:i4>1</vt:i4></vt:variant></vt:vector></HeadingPairs>'
            . '<TitlesOfParts><vt:vector size="1" baseType="lpstr">'
            . sprintf('<vt:lpstr>%s</vt:lpstr>', $this->escapeExcelXml($sheetName))
            . '</vt:vector></TitlesOfParts>'
            . '<Company></Company>'
            . '<LinksUpToDate>false</LinksUpToDate>'
            . '<SharedDoc>false</SharedDoc>'
            . '<HyperlinksChanged>false</HyperlinksChanged>'
            . '<AppVersion>16.0300</AppVersion>'
            . '</Properties>';
    }

    protected function getExcelCorePropertiesXml(string $title, Carbon $exportedAt): string
    {
        $timestamp = $exportedAt->copy()->utc()->format('Y-m-d\TH:i:s\Z');

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            . '<dc:creator>Yuusuke Nishiyama</dc:creator>'
            . '<cp:lastModifiedBy>Yuusuke Nishiyama</cp:lastModifiedBy>'
            . sprintf('<dc:title>%s</dc:title>', $this->escapeExcelXml($title))
            . '<dc:description>試作依頼台帳の Excel 出力</dc:description>'
            . sprintf('<dcterms:created xsi:type="dcterms:W3CDTF">%s</dcterms:created>', $timestamp)
            . sprintf('<dcterms:modified xsi:type="dcterms:W3CDTF">%s</dcterms:modified>', $timestamp)
            . '</cp:coreProperties>';
    }

    protected function resolveExportCellText(array $cell, array $column): string
    {
        if (($column['key'] ?? '') === 'supplement_documents') {
            $documents = collect($cell['documents'] ?? [])
                ->pluck('name')
                ->filter()
                ->values()
                ->all();

            return implode("\n", $documents);
        }

        $value = (string) ($cell['display'] ?? $cell['raw'] ?? '');

        return $value === '-' ? '' : $value;
    }

    protected function shouldWrapExcelCell(string $value, array $column): bool
    {
        if ($value === '') {
            return false;
        }

        if (str_contains($value, "\n")) {
            return true;
        }

        if (($column['editor'] ?? '') === 'textarea') {
            return true;
        }

        return mb_strlen($value) > 28;
    }

    protected function resolveExcelSheetName(string $value): string
    {
        $sanitized = preg_replace('/[\\\\\\/?*\\[\\]:]/u', ' ', $value) ?: 'Sheet1';
        $sanitized = trim($sanitized);
        if ($sanitized === '') {
            $sanitized = 'Sheet1';
        }

        return mb_substr($sanitized, 0, 31);
    }

    protected function getExcelCellXml(string $cellRef, string $value, int $styleId): string
    {
        return sprintf(
            '<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>',
            $cellRef,
            $styleId,
            $this->escapeExcelXml($value)
        );
    }

    protected function getExcelColumnLetter(int $index): string
    {
        $letter = '';

        while ($index > 0) {
            $index--;
            $letter = chr(65 + ($index % 26)) . $letter;
            $index = intdiv($index, 26);
        }

        return $letter ?: 'A';
    }

    protected function escapeExcelXml(string $value): string
    {
        $sanitized = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $value) ?? '';

        return htmlspecialchars($sanitized, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }

    protected function resolveCellValue(CustomValue $value, array $column, ?CustomColumn $customColumn, array $documents = []): array
    {
        $key = $column['key'];
        $editor = $column['editor'] ?? 'readonly';

        if ($key === 'actions') {
            return ['raw' => null, 'display' => null];
        }

        if ($key === 'created_user') {
            return [
                'raw' => $value->created_user_id,
                'display' => $this->displayCreatedUser($value),
            ];
        }

        if ($key === 'supplement_documents') {
            return [
                'raw' => (string) count($documents),
                'display' => count($documents) > 0 ? count($documents) . '件' : '未添付',
                'documents' => $documents,
            ];
        }

        $raw = $value->getValue($key);
        $display = $value->getValue($key, true);

        if ($editor === 'checkbox') {
            $checked = $this->isTruthy($raw);
            return [
                'raw' => $checked ? '1' : '0',
                'display' => $checked ? 'はい' : 'いいえ',
            ];
        }

        if ($editor === 'date') {
            return [
                'raw' => $this->formatDateForInput($raw),
                'display' => $display ?: $this->formatDateForInput($raw),
            ];
        }

        if ($editor === 'datetime') {
            return [
                'raw' => $this->formatDateTimeForInput($raw),
                'display' => $display ?: $this->formatDateTimeForInput($raw),
            ];
        }

        return [
            'raw' => is_array($raw) ? json_encode($raw, JSON_UNESCAPED_UNICODE) : (string) ($raw ?? ''),
            'display' => is_array($display) ? implode(', ', $display) : (string) ($display ?? ''),
        ];
    }

    protected function displayValue(CustomValue $value, string $columnName): string
    {
        return (string) ($value->getValue($columnName, true) ?: $value->getValue($columnName) ?: '-');
    }

    protected function displayCreatedUser(CustomValue $value): string
    {
        $createdUser = $value->created_user;

        if (is_object($createdUser) && method_exists($createdUser, 'getLabel')) {
            return (string) $createdUser->getLabel();
        }

        return (string) ($createdUser ?: '-');
    }

    protected function yesNoLabel($value): string
    {
        return $this->isTruthy($value) ? 'はい' : 'いいえ';
    }

    protected function resolveEditorType(CustomColumn $column): string
    {
        switch ((string) $column->column_type) {
            case 'text':
                return 'text';
            case 'textarea':
                return 'textarea';
            case 'date':
                return 'date';
            case 'datetime':
                return 'datetime';
            case 'yesno':
                return 'checkbox';
            case 'select':
            case 'select_valtext':
                return 'select';
            default:
                return 'readonly';
        }
    }

    protected function resolveEditorOptions(CustomColumn $column, string $editor): array
    {
        if ($editor === 'checkbox') {
            return ['1' => 'はい', '0' => 'いいえ'];
        }

        if ($editor === 'select') {
            return $column->createSelectOptions();
        }

        return [];
    }

    protected function normalizeInput($input, CustomColumn $column, string $editor)
    {
        switch ($editor) {
            case 'checkbox':
                return $this->isTruthy($input) ? '1' : '0';
            case 'date':
                return is_nullorempty($input) ? null : Carbon::parse($input)->format('Y-m-d');
            case 'datetime':
                return is_nullorempty($input) ? null : Carbon::parse($input)->format('Y-m-d H:i:s');
            case 'textarea':
            case 'text':
                $value = is_string($input) ? trim($input) : $input;
                return $value === '' ? null : $value;
            case 'select':
                return is_nullorempty($input) ? null : (string) $input;
            default:
                return $input;
        }
    }

    protected function isTruthy($value): bool
    {
        return in_array((string) $value, ['1', 'true', 'on', 'yes'], true);
    }

    protected function formatDateForInput($value): ?string
    {
        if (is_nullorempty($value)) {
            return null;
        }

        return Carbon::parse($value)->format('Y-m-d');
    }

    protected function formatDateTimeForInput($value): ?string
    {
        if (is_nullorempty($value)) {
            return null;
        }

        return Carbon::parse($value)->format('Y-m-d\TH:i');
    }

    protected function buildSummary(CustomTable $table): array
    {
        $analysis = $this->buildAnalysis($table);

        return [
            'total' => $analysis['totals']['total'],
            'cancelled' => $analysis['totals']['cancelled'],
            'bulk_linked' => $analysis['totals']['bulk_linked'],
            'overdue' => $analysis['totals']['overdue'],
        ];
    }

    protected function buildAnalysis(CustomTable $table): array
    {
        $values = $table->getValueQuery()
            ->orderBy('updated_at', 'desc')
            ->get();

        $today = Carbon::today();

        $progressCounts = [];
        $monthlyCounts = [];
        $overdueItems = [];

        $totals = [
            'total' => $values->count(),
            'cancelled' => 0,
            'bulk_linked' => 0,
            'completed' => 0,
            'overdue' => 0,
        ];

        foreach ($values as $value) {
            $progressStatus = (string) ($value->getValue('progress_status', true) ?: '未設定');
            $requestDate = $value->getValue('request_date');
            $salesDueDate = $value->getValue('sales_due_date');
            $actualFinish = $value->getValue('actual_finish');
            $cancelled = $this->isTruthy($value->getValue('cancelled'));
            $bulkLinked = $this->isTruthy($value->getValue('bulk_linked'));
            $completed = $progressStatus === '完了' || !is_nullorempty($actualFinish);

            $progressCounts[$progressStatus] = ($progressCounts[$progressStatus] ?? 0) + 1;

            if (!is_nullorempty($requestDate)) {
                $month = Carbon::parse($requestDate)->format('Y-m');
                $monthlyCounts[$month] = ($monthlyCounts[$month] ?? 0) + 1;
            }

            if ($cancelled) {
                $totals['cancelled']++;
            }

            if ($bulkLinked) {
                $totals['bulk_linked']++;
            }

            if ($completed) {
                $totals['completed']++;
            }

            if (!$cancelled && !$completed && !is_nullorempty($salesDueDate) && Carbon::parse($salesDueDate)->lt($today)) {
                $totals['overdue']++;
                $overdueItems[] = [
                    'request_no' => $value->getValue('request_no', true),
                    'customer_name' => $value->getValue('customer_name', true),
                    'usage_purpose' => $value->getValue('usage_purpose', true),
                    'progress_status' => $progressStatus,
                    'sales_due_date' => Carbon::parse($salesDueDate)->format('Y-m-d'),
                    'url' => admin_urls('data', $table->table_name, $value->id),
                ];
            }
        }

        ksort($monthlyCounts);

        return [
            'totals' => $totals,
            'progress_counts' => $progressCounts,
            'monthly_counts' => $monthlyCounts,
            'overdue_items' => collect($overdueItems)->sortBy('sales_due_date')->values()->all(),
            'recent_items' => $values->take(10)->map(function (CustomValue $value) use ($table) {
                return [
                    'request_no' => $value->getValue('request_no', true),
                    'customer_name' => $value->getValue('customer_name', true),
                    'progress_status' => $value->getValue('progress_status', true),
                    'updated_at' => optional($value->updated_at)->format('Y-m-d H:i'),
                    'url' => admin_urls('data', $table->table_name, $value->id),
                ];
            })->values()->all(),
        ];
    }
}
