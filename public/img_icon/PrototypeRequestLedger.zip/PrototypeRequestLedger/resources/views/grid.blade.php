<div
    class="prototype-ledger"
    data-prototype-ledger-grid
    data-table-name="{{ $table->table_name }}"
    data-standard-data-url="{{ $table_url }}"
    data-standard-store-url="{{ $standard_store_url }}"
    data-update-url="{{ $update_url }}"
    data-bulk-update-url="{{ $bulk_update_url }}"
    data-store-url="{{ $store_url }}"
    data-detail-url="{{ $detail_url }}"
    data-document-upload-url="{{ $document_upload_url }}"
    data-document-delete-url="{{ $document_delete_url }}"
    data-comment-store-url="{{ $comment_store_url }}"
    data-comment-delete-url="{{ $comment_delete_url }}"
>
    <script type="application/json" data-detail-store>@json($details_by_id, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)</script>

    <div class="prototype-ledger-card prototype-ledger-card--hero">
        <div>
            <div class="prototype-ledger-eyebrow">{{ $table->table_view_name }}</div>
            <h2 class="prototype-ledger-title">{{ $preset['label'] }}</h2>
        </div>
        <div class="prototype-ledger-actions">
            <button type="button" class="btn btn-primary" data-create-modal-open>新規作成</button>
            <button type="button" class="btn btn-default" data-export-excel-url="{{ $export_url }}">Excel出力</button>
            <a class="btn btn-default" href="{{ $analysis_url }}">分析ページ</a>
        </div>
    </div>

    <form class="prototype-ledger-toolbar" method="get">
        @if(request()->get('view'))
            <input type="hidden" name="view" value="{{ request()->get('view') }}">
        @endif
        <input type="hidden" name="table_name" value="{{ $table->table_name }}">
        <div class="prototype-ledger-search">
            <input
                type="text"
                name="q"
                value="{{ $search }}"
                class="form-control"
                placeholder="依頼№ / 客先 / 用途 / 品番を検索"
            >
            <button type="submit" class="btn btn-default">検索</button>
        </div>
        <div class="prototype-ledger-toolbar__meta">
            <select class="form-control" name="per_page" onchange="this.form.submit()">
                @foreach([10,20,30,50,100] as $count)
                    <option value="{{ $count }}" @if($per_page == $count) selected @endif>{{ $count }}件</option>
                @endforeach
            </select>
        </div>
    </form>

    <div class="prototype-ledger-bulkbar">
        <div class="prototype-ledger-bulkbar__left">
            <span data-selected-count>0 件選択</span>
        </div>
        <div class="prototype-ledger-actions">
            <button type="button" class="btn btn-default" data-bulk-action="set_bulk_linked">一括バルク決定</button>
        </div>
    </div>

    <div class="prototype-ledger-tablewrap">
        <table class="prototype-ledger-table">
            <thead>
                <tr>
                    <th class="prototype-ledger-table__select sticky-cell" style="left:0; min-width:44px; width:44px;">
                        <input type="checkbox" data-select-all>
                    </th>
                    @foreach($columns as $column)
                        <th
                            class="@if($column['sticky_enabled']) sticky-cell @endif"
                            style="min-width:{{ $column['width'] }}px; width:{{ $column['width'] }}px; @if($column['sticky_enabled']) left:{{ $column['left'] + 44 }}px; @endif"
                        >
                            {{ $column['label'] }}
                        </th>
                    @endforeach
                </tr>
            </thead>
            <tbody>
                @forelse($rows as $row)
                    @php
                        $cancelled = ($row['cells']['cancelled']['raw'] ?? '0') === '1';
                        $requestNo = $row['cells']['request_no']['display'] ?? ('ID:' . $row['id']);
                    @endphp
                    <tr data-row-id="{{ $row['id'] }}" @if($cancelled) class="is-cancelled" @endif>
                        <td class="prototype-ledger-table__select sticky-cell" style="left:0; min-width:44px; width:44px;">
                            <input type="checkbox" data-row-check value="{{ $row['id'] }}">
                        </td>
                        @foreach($columns as $column)
                            @php
                                $cell = $row['cells'][$column['key']] ?? ['raw' => '', 'display' => ''];
                            @endphp
                            <td
                                class="@if($column['sticky_enabled']) sticky-cell @endif"
                                style="min-width:{{ $column['width'] }}px; width:{{ $column['width'] }}px; @if($column['sticky_enabled']) left:{{ $column['left'] + 44 }}px; @endif"
                            >
                                @if($column['key'] === 'actions')
                                    <div class="prototype-ledger-rowactions">
                                        <button type="button" class="btn btn-xs btn-default" data-detail-open="click" data-row-id="{{ $row['id'] }}" data-row-label="{{ $requestNo }}">詳細</button>
                                        <button type="button" class="btn btn-xs btn-default" data-row-action="set_bulk_linked">バルク決定</button>
                                        @if(($row['cells']['cancelled']['raw'] ?? '0') === '1')
                                            <button type="button" class="btn btn-xs btn-default" data-row-action="clear_cancelled">取消</button>
                                        @else
                                            <button type="button" class="btn btn-xs btn-warning" data-row-action="set_cancelled">中止</button>
                                        @endif
                                        <button type="button" class="btn btn-xs btn-danger" data-row-action="delete">削除</button>
                                    </div>
                                @elseif($column['key'] === 'request_no')
                                    <button
                                        type="button"
                                        class="prototype-ledger-idlink"
                                        data-detail-open="click"
                                        data-row-id="{{ $row['id'] }}"
                                        data-row-label="{{ $requestNo }}"
                                        title="クリックで詳細"
                                    >
                                        {{ $cell['display'] }}
                                    </button>
                                @elseif(($column['editor'] ?? 'readonly') === 'documents')
                                    <div class="prototype-ledger-documents">
                                        @if(!empty($cell['documents']))
                                            <div class="prototype-ledger-documents__list">
                                                @foreach($cell['documents'] as $document)
                                                    <a class="prototype-ledger-doclink" href="{{ $document['url'] }}" target="_blank" rel="noopener">
                                                        {{ $document['name'] }}
                                                    </a>
                                                @endforeach
                                            </div>
                                        @else
                                            <span class="prototype-ledger-documents__empty">未添付</span>
                                        @endif
                                        <button
                                            type="button"
                                            class="btn btn-xs btn-default"
                                            data-detail-open="click"
                                            data-row-id="{{ $row['id'] }}"
                                            data-row-label="{{ $requestNo }}"
                                        >
                                            管理
                                        </button>
                                    </div>
                                @elseif(($column['editor'] ?? 'readonly') === 'checkbox')
                                    <label class="prototype-ledger-checkbox">
                                        <input
                                            type="checkbox"
                                            data-cell-editor
                                            data-editor="checkbox"
                                            data-column="{{ $column['key'] }}"
                                            @if(($cell['raw'] ?? '0') === '1') checked @endif
                                        >
                                    </label>
                                @elseif(($column['editor'] ?? 'readonly') === 'select')
                                    <select
                                        class="form-control prototype-ledger-input"
                                        data-cell-editor
                                        data-editor="select"
                                        data-column="{{ $column['key'] }}"
                                    >
                                        <option value=""></option>
                                        @foreach(($column['options'] ?? []) as $optionValue => $optionLabel)
                                            <option value="{{ $optionValue }}" @if((string)($cell['raw'] ?? '') === (string)$optionValue) selected @endif>
                                                {{ $optionLabel }}
                                            </option>
                                        @endforeach
                                    </select>
                                @elseif(($column['editor'] ?? 'readonly') === 'textarea')
                                    <textarea
                                        rows="2"
                                        class="form-control prototype-ledger-input prototype-ledger-input--textarea"
                                        data-cell-editor
                                        data-editor="textarea"
                                        data-column="{{ $column['key'] }}"
                                    >{{ $cell['raw'] }}</textarea>
                                @elseif(($column['editor'] ?? 'readonly') === 'date')
                                    <input
                                        type="date"
                                        class="form-control prototype-ledger-input"
                                        data-cell-editor
                                        data-editor="date"
                                        data-column="{{ $column['key'] }}"
                                        value="{{ $cell['raw'] }}"
                                    >
                                @elseif(($column['editor'] ?? 'readonly') === 'datetime')
                                    <input
                                        type="datetime-local"
                                        class="form-control prototype-ledger-input"
                                        data-cell-editor
                                        data-editor="datetime"
                                        data-column="{{ $column['key'] }}"
                                        value="{{ $cell['raw'] }}"
                                    >
                                @elseif(($column['editor'] ?? 'readonly') === 'text')
                                    <input
                                        type="text"
                                        class="form-control prototype-ledger-input"
                                        data-cell-editor
                                        data-editor="text"
                                        data-column="{{ $column['key'] }}"
                                        value="{{ $cell['raw'] }}"
                                    >
                                @elseif(isset($cell['badge_class']))
                                    <span class="prototype-ledger-badge {{ $cell['badge_class'] }}">{{ $cell['display'] }}</span>
                                @else
                                    <span class="prototype-ledger-text" title="{{ $cell['display'] }}">{{ $cell['display'] }}</span>
                                @endif
                            </td>
                        @endforeach
                    </tr>
                @empty
                    <tr>
                        <td colspan="{{ count($columns) + 1 }}" class="prototype-ledger-empty">データがありません。</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="prototype-ledger-pagination">
        {{ $paginator->links() }}
    </div>

    <div class="prototype-ledger-modal" data-ledger-modal="create" hidden>
        <div class="prototype-ledger-modal__backdrop" data-modal-close></div>
        <div class="prototype-ledger-modal__dialog prototype-ledger-modal__dialog--wide" role="dialog" aria-modal="true" aria-labelledby="prototype-ledger-create-title">
            <div class="prototype-ledger-modal__header">
                <div>
                    <div class="prototype-ledger-eyebrow">Quick Create</div>
                    <h3 class="prototype-ledger-section-title" id="prototype-ledger-create-title">試作依頼をモーダルで登録</h3>
                </div>
                <button type="button" class="prototype-ledger-modal__close" data-modal-close aria-label="閉じる">×</button>
            </div>

            <form class="prototype-ledger-modal__body" data-create-form enctype="multipart/form-data">
                {{ csrf_field() }}
                <input type="hidden" name="table_name" value="{{ $table->table_name }}">

                <div class="prototype-ledger-form-error" data-create-form-error hidden></div>

                @foreach($create_form_sections as $section)
                    <section class="prototype-ledger-form-section">
                        <div class="prototype-ledger-form-section__head">
                            <h4>{{ $section['title'] }}</h4>
                            @if(!empty($section['description']))
                                <p>{{ $section['description'] }}</p>
                            @endif
                        </div>
                        <div class="prototype-ledger-form-grid">
                            @foreach($section['fields'] as $field)
                                @if($field['control'] === 'checkbox')
                                    <label class="prototype-ledger-field prototype-ledger-field--check">
                                        <input type="checkbox" name="{{ $field['name'] }}" value="1">
                                        <span>{{ $field['label'] }}</span>
                                    </label>
                                @else
                                    <label class="prototype-ledger-field @if(!empty($field['full_width'])) is-full @endif">
                                        <span class="prototype-ledger-field__label">
                                            {{ $field['label'] }}
                                            @if(!empty($field['required']))
                                                <small>必須</small>
                                            @endif
                                        </span>

                                        @if($field['control'] === 'textarea')
                                            <textarea
                                                class="form-control"
                                                name="{{ $field['name'] }}"
                                                rows="3"
                                                placeholder="{{ $field['placeholder'] ?? '' }}"
                                                @if(!empty($field['required'])) required @endif
                                            ></textarea>
                                        @elseif($field['control'] === 'select')
                                            <select class="form-control" name="{{ $field['name'] }}" @if(!empty($field['required'])) required @endif>
                                                <option value=""></option>
                                                @foreach(($field['options'] ?? []) as $optionValue => $optionLabel)
                                                    <option value="{{ $optionValue }}" @if(($field['default'] ?? null) !== null && (string)$field['default'] === (string)$optionValue) selected @endif>
                                                        {{ $optionLabel }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        @elseif($field['control'] === 'date')
                                            <input
                                                type="date"
                                                class="form-control"
                                                name="{{ $field['name'] }}"
                                                value="{{ $field['default'] ?? '' }}"
                                                @if(!empty($field['required'])) required @endif
                                            >
                                        @elseif($field['control'] === 'datetime')
                                            <input
                                                type="datetime-local"
                                                class="form-control"
                                                name="{{ $field['name'] }}"
                                                value="{{ $field['default'] ?? '' }}"
                                                @if(!empty($field['required'])) required @endif
                                            >
                                        @elseif($field['control'] === 'file')
                                            <input
                                                type="file"
                                                class="form-control"
                                                name="{{ $field['name'] }}[]"
                                                @if(!empty($field['multiple'])) multiple @endif
                                            >
                                        @else
                                            <input
                                                type="text"
                                                class="form-control"
                                                name="{{ $field['name'] }}"
                                                value="{{ $field['default'] ?? '' }}"
                                                placeholder="{{ $field['placeholder'] ?? '' }}"
                                                @if(!empty($field['required'])) required @endif
                                            >
                                        @endif

                                        @if(!empty($field['hint']))
                                            <small class="prototype-ledger-field__hint">{{ $field['hint'] }}</small>
                                        @endif
                                    </label>
                                @endif
                            @endforeach
                        </div>
                    </section>
                @endforeach

                <div class="prototype-ledger-modal__footer">
                    <button type="button" class="btn btn-default" data-modal-close>閉じる</button>
                    <button type="submit" class="btn btn-primary" data-create-submit>登録する</button>
                </div>
            </form>
        </div>
    </div>

    <div class="prototype-ledger-modal" data-ledger-modal="detail" hidden>
        <div class="prototype-ledger-modal__backdrop" data-modal-close></div>
        <div class="prototype-ledger-modal__dialog prototype-ledger-modal__dialog--detail" role="dialog" aria-modal="true" aria-labelledby="prototype-ledger-detail-title">
            <div class="prototype-ledger-modal__header">
                <div>
                    <div class="prototype-ledger-eyebrow">Request Detail</div>
                    <h3 class="prototype-ledger-section-title" id="prototype-ledger-detail-title" data-detail-title>依頼詳細</h3>
                </div>
                <button type="button" class="prototype-ledger-modal__close" data-modal-close aria-label="閉じる">×</button>
            </div>

            <div class="prototype-ledger-modal__body">
                <div class="prototype-ledger-form-error" data-detail-error hidden></div>
                <div class="prototype-ledger-detail-loading" data-detail-loading>詳細を読み込み中です...</div>

                <div data-detail-body hidden>
                    <div class="prototype-ledger-detail-hero">
                        <div>
                            <div class="prototype-ledger-detail-hero__title" data-detail-request-no></div>
                            <div class="prototype-ledger-detail-hero__sub" data-detail-summary-copy></div>
                        </div>
                    </div>

                    <div class="prototype-ledger-detail-grid">
                        <section class="prototype-ledger-card">
                            <h4 class="prototype-ledger-section-title">基本情報</h4>
                            <div class="prototype-ledger-detail-list" data-detail-summary></div>
                        </section>

                        <section class="prototype-ledger-card">
                            <h4 class="prototype-ledger-section-title">依頼内容</h4>
                            <div class="prototype-ledger-detail-list" data-detail-request-flags></div>
                        </section>
                    </div>

                    <div class="prototype-ledger-detail-grid">
                        <section class="prototype-ledger-card">
                            <h4 class="prototype-ledger-section-title">計画工程</h4>
                            <div class="prototype-ledger-detail-list" data-detail-planning></div>
                        </section>

                        <section class="prototype-ledger-card">
                            <h4 class="prototype-ledger-section-title">実績工程</h4>
                            <div class="prototype-ledger-detail-list" data-detail-actual></div>
                        </section>
                    </div>

                    <section class="prototype-ledger-card">
                        <h4 class="prototype-ledger-section-title">メモ</h4>
                        <div class="prototype-ledger-detail-notes" data-detail-notes></div>
                    </section>

                    <div class="prototype-ledger-detail-grid">
                        <section class="prototype-ledger-card">
                            <h4 class="prototype-ledger-section-title">補足資料</h4>
                            <div class="prototype-ledger-documents-panel">
                                <div data-detail-document-list></div>
                            </div>
                            <form data-detail-document-form enctype="multipart/form-data">
                                {{ csrf_field() }}
                                <input type="hidden" name="table_name" value="{{ $table->table_name }}">
                                <input type="hidden" name="id" value="" data-detail-id>
                                <label class="prototype-ledger-field is-full">
                                    <span class="prototype-ledger-field__label">資料を追加</span>
                                    <input type="file" class="form-control" name="supplement_files[]" multiple>
                                </label>
                                <div class="prototype-ledger-inline-actions">
                                    <button type="submit" class="btn btn-primary" data-detail-document-submit>アップロード</button>
                                </div>
                            </form>
                        </section>

                        <section class="prototype-ledger-card">
                            <h4 class="prototype-ledger-section-title">コメント</h4>
                            <div class="prototype-ledger-comments" data-detail-comment-list></div>
                            <form data-detail-comment-form>
                                {{ csrf_field() }}
                                <input type="hidden" name="table_name" value="{{ $table->table_name }}">
                                <input type="hidden" name="id" value="" data-detail-comment-id>
                                <label class="prototype-ledger-field is-full">
                                    <span class="prototype-ledger-field__label">コメント追加</span>
                                    <textarea class="form-control" name="comment" rows="3" placeholder="コメントを入力"></textarea>
                                </label>
                                <div class="prototype-ledger-inline-actions">
                                    <button type="submit" class="btn btn-primary" data-detail-comment-submit>コメント保存</button>
                                </div>
                            </form>
                        </section>
                    </div>
                </div>

                <div class="prototype-ledger-modal__footer">
                    <button type="button" class="btn btn-default" data-modal-close>閉じる</button>
                </div>
            </div>
        </div>
    </div>
</div>
