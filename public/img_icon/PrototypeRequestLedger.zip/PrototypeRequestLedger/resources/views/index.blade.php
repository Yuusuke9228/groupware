<div class="prototype-ledger-page prototype-ledger-home">
    <div class="prototype-ledger-card prototype-ledger-card--hero">
        <div>
            <div class="prototype-ledger-eyebrow">Prototype Request Suite</div>
            <h2 class="prototype-ledger-title">試作依頼の申請と進行を、画面遷移を減らして運用するためのプラグインです。</h2>
            <p class="prototype-ledger-copy">
                テンプレートで作成したカスタムテーブルに対して、Excel 風の横並び一覧、進行分析、初期ビュー作成をまとめて提供します。
            </p>
        </div>
        <div class="prototype-ledger-actions">
            <a class="btn btn-primary" href="{{ $analysis_url }}">分析ページ</a>
        </div>
    </div>

    @if(!$table)
        <div class="prototype-ledger-card">
            <h3 class="prototype-ledger-section-title">テーブル未検出</h3>
            <p class="prototype-ledger-copy">
                既定テーブル <code>{{ $table_name }}</code> が見つかりませんでした。プラグイン ZIP をインストールするとテンプレートが自動導入される想定です。
            </p>
        </div>
    @else
        @if($summary)
            <div class="prototype-ledger-stats">
                <div class="prototype-ledger-stat">
                    <div class="prototype-ledger-stat__label">総件数</div>
                    <div class="prototype-ledger-stat__value">{{ $summary['total'] }}</div>
                </div>
                <div class="prototype-ledger-stat">
                    <div class="prototype-ledger-stat__label">キャンセル</div>
                    <div class="prototype-ledger-stat__value">{{ $summary['cancelled'] }}</div>
                </div>
                <div class="prototype-ledger-stat">
                    <div class="prototype-ledger-stat__label">バルク決定済</div>
                    <div class="prototype-ledger-stat__value">{{ $summary['bulk_linked'] }}</div>
                </div>
                <div class="prototype-ledger-stat">
                    <div class="prototype-ledger-stat__label">期限超過</div>
                    <div class="prototype-ledger-stat__value">{{ $summary['overdue'] }}</div>
                </div>
            </div>
        @endif

        <div class="prototype-ledger-card">
            <h3 class="prototype-ledger-section-title">セットアップ</h3>
            <p class="prototype-ledger-copy">
                既定ビューを作成すると、Exment のビュー切り替えから「試作依頼一覧」「開発依頼」「試作進行」を選べるようになります。
            </p>
            <form method="post" action="{{ $setup_url }}">
                {{ csrf_field() }}
                <input type="hidden" name="table_name" value="{{ $table->table_name }}">
                <button type="submit" class="btn btn-primary">既定ビューを作成する</button>
            </form>
        </div>
    @endif
</div>
