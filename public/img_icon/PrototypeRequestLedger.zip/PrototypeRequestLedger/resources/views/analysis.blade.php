<div class="prototype-ledger-page prototype-ledger-analysis">
    <div class="prototype-ledger-card prototype-ledger-card--hero">
        <div>
            <div class="prototype-ledger-eyebrow">{{ $table->table_view_name }}</div>
            <h2 class="prototype-ledger-title">試作依頼の分析ダッシュボード</h2>
            <p class="prototype-ledger-copy">進捗区分、期限超過、月別件数を確認できます。</p>
        </div>
       
    </div>

    <div class="prototype-ledger-stats">
        <div class="prototype-ledger-stat">
            <div class="prototype-ledger-stat__label">総件数</div>
            <div class="prototype-ledger-stat__value">{{ $analysis['totals']['total'] }}</div>
        </div>
        <div class="prototype-ledger-stat">
            <div class="prototype-ledger-stat__label">完了</div>
            <div class="prototype-ledger-stat__value">{{ $analysis['totals']['completed'] }}</div>
        </div>
        <div class="prototype-ledger-stat">
            <div class="prototype-ledger-stat__label">キャンセル</div>
            <div class="prototype-ledger-stat__value">{{ $analysis['totals']['cancelled'] }}</div>
        </div>
        <div class="prototype-ledger-stat">
            <div class="prototype-ledger-stat__label">バルク決定済</div>
            <div class="prototype-ledger-stat__value">{{ $analysis['totals']['bulk_linked'] }}</div>
        </div>
        <div class="prototype-ledger-stat">
            <div class="prototype-ledger-stat__label">期限超過</div>
            <div class="prototype-ledger-stat__value">{{ $analysis['totals']['overdue'] }}</div>
        </div>
    </div>

    <div class="prototype-ledger-grid">
        <div class="prototype-ledger-card">
            <h3 class="prototype-ledger-section-title">進捗区分別件数</h3>
            <table class="prototype-ledger-simpletable">
                <thead>
                    <tr>
                        <th>区分</th>
                        <th>件数</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($analysis['progress_counts'] as $label => $count)
                        <tr>
                            <td>{{ $label }}</td>
                            <td>{{ $count }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="2">データがありません。</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="prototype-ledger-card">
            <h3 class="prototype-ledger-section-title">月別受付件数</h3>
            <table class="prototype-ledger-simpletable">
                <thead>
                    <tr>
                        <th>月</th>
                        <th>件数</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($analysis['monthly_counts'] as $month => $count)
                        <tr>
                            <td>{{ $month }}</td>
                            <td>{{ $count }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="2">データがありません。</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="prototype-ledger-card">
        <h3 class="prototype-ledger-section-title">最近更新された依頼</h3>
        <table class="prototype-ledger-simpletable">
            <thead>
                <tr>
                    <th>依頼№</th>
                    <th>客先</th>
                    <th>進捗</th>
                    <th>更新日時</th>
                </tr>
            </thead>
            <tbody>
                @forelse($analysis['recent_items'] as $item)
                    <tr>
                        <td><a href="{{ $item['url'] }}">{{ $item['request_no'] }}</a></td>
                        <td>{{ $item['customer_name'] }}</td>
                        <td>{{ $item['progress_status'] }}</td>
                        <td>{{ $item['updated_at'] }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4">データがありません。</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="prototype-ledger-card">
        <h3 class="prototype-ledger-section-title">期限超過一覧</h3>
        <table class="prototype-ledger-simpletable">
            <thead>
                <tr>
                    <th>依頼№</th>
                    <th>客先</th>
                    <th>用途</th>
                    <th>進捗</th>
                    <th>営業希望納期</th>
                </tr>
            </thead>
            <tbody>
                @forelse($analysis['overdue_items'] as $item)
                    <tr>
                        <td><a href="{{ $item['url'] }}">{{ $item['request_no'] }}</a></td>
                        <td>{{ $item['customer_name'] }}</td>
                        <td>{{ $item['usage_purpose'] }}</td>
                        <td>{{ $item['progress_status'] }}</td>
                        <td>{{ $item['sales_due_date'] }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5">期限超過の依頼はありません。</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>